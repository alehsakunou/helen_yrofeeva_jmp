package com.epam.spring.core.helen.yrofeeva.services;

import java.util.Collection;
import java.util.Date;

import com.epam.spring.core.helen.yrofeeva.dto.Event;
import com.epam.spring.core.helen.yrofeeva.dto.EventAction;
import com.epam.spring.core.helen.yrofeeva.persistent.Auditorium;

public interface EventActionService {
    EventAction addEventAction(Event event, Auditorium auditorium, Date date);
    void removeEventAction(EventAction eventAction);
    /** return events between dates*/
    Collection<EventAction> getEventActions(Date start, Date end);
    /** return all event actions for some event*/
    Collection<EventAction> getEventActions(Event event);
    /** return all event actions for some auditorium*/
    Collection<EventAction> getEventActions(Auditorium auditorium);
    /** return all event actions from date for some event */
    Collection<EventAction> getEventActions(Event event, Date date);
    /** return event actions from date for some auditorium */
    Collection<EventAction> getEventActions(Auditorium auditorium, Date date);
}

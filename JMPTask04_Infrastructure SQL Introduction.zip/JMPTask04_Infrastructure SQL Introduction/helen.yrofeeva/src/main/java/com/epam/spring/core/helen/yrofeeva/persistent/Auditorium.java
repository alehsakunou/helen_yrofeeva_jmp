package com.epam.spring.core.helen.yrofeeva.persistent;

/**
 * 
 * info about auditoriums and places
 * Since auditorium information is usually static, store it in some property file.
 * Several auditoriums can be stored in separate property files,
 * information from them could be injected into the AuditoriumService
 */

public class Auditorium {
    private int id;
    private String name;
    private String adress;
    /** comma-separated list of seats */
    private String seats;
    /** comma-separated list of expensive seats */
    private String vipSeats;
    /** price seats should be multiply to this coeff*/
    private double vipCoeff;
    
    public Auditorium(){
        
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAdress() {
        return adress;
    }

    public void setAdress(String adress) {
        this.adress = adress;
    }

    public String getSeats() {
        return seats;
    }

    public void setSeats(String seats) {
        this.seats = seats;
    }

    public String getVipSeats() {
        return vipSeats;
    }

    public void setVipSeats(String vipSeats) {
        this.vipSeats = vipSeats;
    }
    
    public double getVipCoeff() {
        return vipCoeff;
    }

    public void setVipCoeff(double vipCoeff) {
        this.vipCoeff = vipCoeff;
    }

    @Override
    public String toString() {
        return "Auditorium [id=" + id + ", name=" + name + ", adress=" + adress + ", seats=" + seats + ", vipSeats=" + vipSeats
                + ", vipCoeff=" + vipCoeff + "]";
    }
    


}

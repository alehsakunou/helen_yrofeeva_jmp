package com.epam.spring.core.helen.yrofeeva.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * class User
 * admin can manage by Events
 */
public class User extends ObjectDTO implements Serializable{
    private static final long serialVersionUID = 1L;
    /** true if admin*/
    private boolean isAdmin;//TODO: what is this field for? for future ^_^
    private String name;
    private String email;
    private Date birthday;
    
    public User(){
        
    }
    
    public User(int id, boolean admin, String name, String email, Date birthday) {
        super();
        this.id = id;
        this.isAdmin = admin;
        this.name = name;
        this.email = email;
        this.birthday = birthday;
    }

    public boolean isAdmin() {
        return isAdmin;
    }
    
    public void setAdmin(boolean admin) {
        this.isAdmin = admin;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    @Override
    public String toString() {
        return "User [id=" + id + ", admin=" + isAdmin + ", name=" + name + ", email=" + email + ", birthday=" + birthday + "]";
    }
  
}

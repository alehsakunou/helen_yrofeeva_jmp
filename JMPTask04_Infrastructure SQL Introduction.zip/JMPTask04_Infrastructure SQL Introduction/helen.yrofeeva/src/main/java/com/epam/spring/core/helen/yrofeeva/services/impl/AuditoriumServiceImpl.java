package com.epam.spring.core.helen.yrofeeva.services.impl;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;

import com.epam.spring.core.helen.yrofeeva.persistent.Auditorium;
import com.epam.spring.core.helen.yrofeeva.services.AuditoriumService;

//TODO: auditorium works over single entity (we need multi auditoriums environment). Need to update.
//HY: I looked for PropertiesFactoryBean but I really don't understand how I can use it.
//TODO: do you see any other way to use more that 1 auditorium? We can discus it in a chat later
public class AuditoriumServiceImpl implements AuditoriumService {
    private Auditorium auditorium;

    public AuditoriumServiceImpl() {
    }

    public AuditoriumServiceImpl(Auditorium auditorium) {
        this.auditorium = auditorium;
    }

    public Auditorium getAuditorium() {
        return auditorium;
    }

    @Autowired
    public void setAuditorium(Auditorium auditorium) {
        this.auditorium = auditorium;
    }

    @Override
    public Set<String> getSeats() {
        Set<String> set = new HashSet<>();
        if (auditorium != null) {
            String[] seats = auditorium.getSeats().split(",");
            set.addAll(Arrays.asList(seats));
        }
        return set;
    }

    @Override
    public Set<String> getVipSeats() {
        Set<String> set = new HashSet<>();
        if (auditorium != null) {
            String[] seats = auditorium.getVipSeats().split(",");
            set.addAll(Arrays.asList(seats));
        }
        return set;
    }

    @Override
    public double getVIPCoeff() {
        return auditorium.getVipCoeff();
    }

}

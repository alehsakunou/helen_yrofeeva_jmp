package com.epam.spring.core.helen.yrofeeva.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * event with concrete datetime and auditorium
 */
public class EventAction extends ObjectDTO implements Serializable {
    private static final long serialVersionUID = 1L;
    private int eventID;
    private int auditoriumID;
    private Date dateTimeStart;

    public EventAction() {

    }

    public EventAction(int id, int eventID, int auditoriumID, Date dateTimeStart) {
        super();
        this.id = id;
        this.eventID = eventID;
        this.auditoriumID = auditoriumID;
        this.dateTimeStart = dateTimeStart;
    }

    public int getEventID() {
        return eventID;
    }

    public void setEventID(int eventID) {
        this.eventID = eventID;
    }

    public int getAuditoriumID() {
        return auditoriumID;
    }

    public void setAuditoriumID(int auditoriumID) {
        this.auditoriumID = auditoriumID;
    }

    public Date getDateTimeStart() {
        return dateTimeStart;
    }

    public void setDateTimeStart(Date dateTimeStart) {
        this.dateTimeStart = dateTimeStart;
    }

    @Override
    public String toString() {
        return "EventAction [id=" + id + ", eventID=" + eventID + ", auditoriumID=" + auditoriumID + ", dateTimeStart=" + dateTimeStart
                + "]";
    }

}

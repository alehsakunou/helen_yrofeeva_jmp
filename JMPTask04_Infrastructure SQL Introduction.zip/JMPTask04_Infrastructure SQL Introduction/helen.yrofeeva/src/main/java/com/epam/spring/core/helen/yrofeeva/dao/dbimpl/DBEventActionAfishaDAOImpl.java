package com.epam.spring.core.helen.yrofeeva.dao.dbimpl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.epam.spring.core.helen.yrofeeva.dao.AfishaDAO;
import com.epam.spring.core.helen.yrofeeva.dto.EventAction;

public class DBEventActionAfishaDAOImpl implements AfishaDAO<EventAction> {
    protected JdbcTemplate jdbcTemplate;
    private static final String SQL_ADD = "INSERT INTO EventActions (ID, eventID, auditoriumID, dateTimeStart) VALUES (?,?,?,?)";
    private static final String SQL_DELETE = "DELETE FROM EventActions WHERE ID = ?";
    private static final String SQL_DELETE_ALL = "DELETE FROM EventActions";
    private static final String SQL_SELECT = "SELECT ID, eventID, auditoriumID, dateTimeStart FROM EventActions WHERE ID = ?";
    private static final String SQL_SELECT_ALL = "SELECT ID, eventID, auditoriumID, dateTimeStart FROM EventActions";
    private static final String SQL_MAX_ID = "SELECT MAX(ID) AS maxID FROM EventActions";

    public DBEventActionAfishaDAOImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private EventAction fillEntity(ResultSet rs) throws SQLException {
        EventAction entity = new EventAction();
        entity.setId(rs.getInt("ID"));
        entity.setEventID(rs.getInt("eventID"));
        entity.setAuditoriumID(rs.getInt("auditoriumID"));
        entity.setDateTimeStart(rs.getDate("dateTimeStart"));
        return entity;
    }

    @Override
    public EventAction getEntity(int id) {
        EventAction entity = jdbcTemplate.queryForObject(SQL_SELECT, new Object[] { id }, new RowMapper<EventAction>() {
            public EventAction mapRow(ResultSet rs, int rowNum) throws SQLException {
                return fillEntity(rs);
            }
        });
        return entity;
    }

    @Override
    public Collection<EventAction> getAll() {
        List<EventAction> all = jdbcTemplate.query(SQL_SELECT_ALL, new RowMapper<EventAction>() {
            public EventAction mapRow(ResultSet rs, int rowNum) throws SQLException {
                return fillEntity(rs);
            }
        });
        return all;
    }

    @Override
    public void add(EventAction e) {
        jdbcTemplate.update(SQL_ADD, e.getId(), e.getEventID(), e.getAuditoriumID(), e.getDateTimeStart());
    }

    @Override
    public void remove(EventAction e) {
        jdbcTemplate.update(SQL_DELETE, e.getId());
    }

    @Override
    public int getMaxId() {
        try {
            return jdbcTemplate.queryForObject(SQL_MAX_ID, Integer.class);
        } catch (Exception e) {
            return 0;
        }
    }

    @Override
    public void removeAll() {
        jdbcTemplate.update(SQL_DELETE_ALL);
    }

    @Override
    public void update(EventAction e) {
        // TODO Auto-generated method stub
        
    }

}

package com.epam.spring.core.helen.yrofeeva;

import java.util.ArrayList;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.epam.spring.core.helen.yrofeeva.aspects.DiscountAspect;
import com.epam.spring.core.helen.yrofeeva.dao.AfishaDAOFactory;
import com.epam.spring.core.helen.yrofeeva.dto.*;
import com.epam.spring.core.helen.yrofeeva.persistent.Auditorium;
import com.epam.spring.core.helen.yrofeeva.services.BookingService;
import com.epam.spring.core.helen.yrofeeva.services.DiscountService;
import com.epam.spring.core.helen.yrofeeva.services.EventActionService;
import com.epam.spring.core.helen.yrofeeva.services.EventService;
import com.epam.spring.core.helen.yrofeeva.services.UserService;
import com.epam.spring.core.helen.yrofeeva.utils.DateUtil;

/**
 * TODO: notes
 *
 * 90+1+1-1(-1 for single auditorium) +1(close ctx and script to show) +1 (object dto) -5 (no DAOs) -3 (10th ticket strategy) -1 (discount
 * service) -1(@Service)
 * -2(setters/getters for service dependencies) -1(get ticket price) -1 (book ticket complication) -1(book ticket without real price)
 * 90-1-1-1-3-1-1-2-1-1-1
 *
 * 1. nice to have configuration into separate properties file.
 *
 * 2. nice to have auditorium in separate properties files
 *
 * 3. But looks like you use only 1 auditorium.. I hoped you use both :( And you have only 1 auditorium. Would be good if you add/implement
 * 1 more.
 *
 * I really don't understand how can I make it T_T (how to use PropertiesFactoryBean)
 *
 * 4. Not critical, but in real apps it's better to use some one way, either xml or annotation. Thus, simple to support it. (in case one
 * person work on app it doesn't matter).
 *
 * 5. nice to see some abstract level of DTO with ID.
 *
 * 6. Don't see DAO layer. (it's not very required for app, but it takes more area for configure beans).
 * 
 * HY: corrected
 * 
 * 7. bad implemented 10th ticket strategy. Need to review it and refactor (or re-implement).
 *
 * HY: corrected
 *
 * 8. You should provide either maximum of possible discounts or sum of them (at least). Would be nice to update it.
 *
 * HY: that's it !!!
 *
 * 9. Don't need to have @Service annotations if you define beans into XML.
 * 
 * HY: corrected
 *
 * 10. Don't need to add getters for injected fields (auditorium service). As don't need to add setters to service interface. Setters of
 * dependency is not API.
 * HINT: also, you don't need setter if you use @Autowired on the field.
 * 
 * HY: corrected
 *
 * 11. Not correct implement getTicketPrice method (not apply discount over ticket).
 * 
 * HY: corrected
 * TODO: don't see that changes
 *
 * 12. Don't use short names 'res' or 'tic'. It reduce readability.
 *
 * HY: corrected
 *
 * P.S. Would be nice to see implemented real price (price with applied discount). And multi auditoriums.
 */

/**
 * TODO: notes
 * 89
 * -1 (not valid pom.xml, missed aspectj version)
 * -1(code style, please don't use short name variables, it reduces readability. That's not problem to use nice names with modern IDE)
 * -1(not well to have only method in pointcut, in future you can have other methods with same names and have issues)
 * [count aspect]
 * -1 (it's better (more safe) to have pointcut by full methods name with &&)
 * -3 (something terrible with calculating calling price and booking by event) (same in discount aspect)
 * [discount aspect]
 * -5 (need to calculate times of EACH strategy was called/applied [in task it's "given"] - you do it for any strategy)
 * +2 (optional task, not implemented completely)
 *
 * relate to prev.
 * +3 for adding DAO with abstraction level
 * +0 for update strategies (it has little issue)
 * +1 for adjust spring configuration little issues
 * -1(fixed getTicketPrice, you apply discount, but still don't store real price in ticket.)
 *
 * 89-1-1-1-1-3-5+2+3+1-1=82
 *
 * 1. HINT, btw, having discount as % is better rather some coefficient. In case of % it's easy to sum them if needed. Also, Discount means
 * some number of % of the original amount.
 *
 * 2. We can organize a chat/call to discuss auditoriums against properties.
 *
 * 3. HINT: bad practice to not use block { } in 1 row body code.
 * Using { } increase readability and easy supporting if you need to add other row
 *
 * P.S.
 * would be perfect to assign DAOs over spring configuration.
 */
public class App {
    public static void clearDB(AfishaDAOFactory daoFactory){
        daoFactory.getAfishaDAODiscountStatistics().removeAll();
        daoFactory.getAfishaDAOEventStatistics().removeAll();
        daoFactory.getAfishaDAOEventAction().removeAll();
        daoFactory.getAfishaDAOEvent().removeAll();
        daoFactory.getAfishaDAOUser().removeAll();
        daoFactory.getAfishaDAOTicket().removeAll();
    }

    public static void main(String[] args) {
        ApplicationContext ctx = new ClassPathXmlApplicationContext("config.xml");

        Auditorium auditorium = (Auditorium) ctx.getBean("auditorium");
        System.out.println(auditorium);

        DateUtil dateUtil = (DateUtil) ctx.getBean("dateUtil");
        AfishaDAOFactory daoFactory = (AfishaDAOFactory) ctx.getBean("dao");
        clearDB(daoFactory);

        User user1 = new User(1, true, "Admin", "admin@epam.com", dateUtil.getDate("28.10.05 00:00"));
        User user2 = new User(2, false, "Ivanov", "ivanov@epam.com", dateUtil.getDate("25.10.1917 00:00"));
        User user3 = new User(3, false, "Admin", "prtrov@epam.com", dateUtil.getDate("25.12.1999 00:00"));
        User user4 = new User(4, false, "SidorOff", "sidorOff@epam.com", dateUtil.getDate("01.01.1985 00:00"));

        Event event1 = new Event(1, "Star wars", EventRating.HIGH, 99.9, 210);
        Event event2 = new Event(2, "Titanic", EventRating.LOW, 9.9, 210);
        Event event3 = new Event(3, "Silent Hill", EventRating.MID, 44.5, 210);

        // TODO: would be better to inject it somehow rather use getBean, might be move it to some class as example
        UserService userService = (UserService) ctx.getBean("userService");
        EventService eventService = (EventService) ctx.getBean("eventService");
        EventActionService eventActionService = (EventActionService) ctx.getBean("eventActionService");
        BookingService bookingService = (BookingService) ctx.getBean("bookingService");
        DiscountService discountService = (DiscountService) ctx.getBean("discountService");

        userService.registerUser(user1);
        userService.registerUser(user2);
        userService.registerUser(user3);
        userService.registerUser(user4);

        userService.removeUser(user4);

        eventService.addEvent(event1);
        eventService.addEvent(event2);
        eventService.addEvent(event3);

        EventAction action11 = eventActionService.addEventAction(event1, auditorium, dateUtil.getDate("28.10.15 10:00"));
        EventAction action12 = eventActionService.addEventAction(event1, auditorium, dateUtil.getDate("25.12.15 10:00"));
        EventAction action13 = eventActionService.addEventAction(event1, auditorium, dateUtil.getDate("25.10.15 10:00"));

        EventAction action21 = eventActionService.addEventAction(event2, auditorium, dateUtil.getDate("28.10.15 13:00"));
        EventAction action22 = eventActionService.addEventAction(event2, auditorium, dateUtil.getDate("25.12.15 13:00"));
        EventAction action23 = eventActionService.addEventAction(event2, auditorium, dateUtil.getDate("25.10.15 13:00"));

        EventAction action31 = eventActionService.addEventAction(event3, auditorium, dateUtil.getDate("28.10.15 21:00"));
        EventAction action32 = eventActionService.addEventAction(event3, auditorium, dateUtil.getDate("25.12.15 21:00"));
        EventAction action33 = eventActionService.addEventAction(event3, auditorium, dateUtil.getDate("25.10.15 21:00"));

        System.out.println("user = " + user1 + " action = " + action31 + " discount = " + discountService.getDiscount(action31, user1));
        System.out.println("user = " + user1 + " action = " + action32 + " discount = " + discountService.getDiscount(action32, user1));
        System.out.println("user = " + user1 + " action = " + action33 + " discount = " + discountService.getDiscount(action33, user1));

        System.out.println("user = " + user2 + " action = " + action11 + " discount = " + discountService.getDiscount(action11, user2));
        System.out.println("user = " + user2 + " action = " + action12 + " discount = " + discountService.getDiscount(action12, user2));
        System.out.println("user = " + user2 + " action = " + action13 + " discount = " + discountService.getDiscount(action13, user2));

        System.out.println("user = " + user3 + " action = " + action21 + " discount = " + discountService.getDiscount(action21, user3));
        System.out.println("user = " + user3 + " action = " + action22 + " discount = " + discountService.getDiscount(action22, user3));
        System.out.println("user = " + user3 + " action = " + action23 + " discount = " + discountService.getDiscount(action23, user3));

        System.out.println(bookingService.getFreeVIPSeats(action31));
        System.out.println(bookingService.bookTicket(action31, user1,
                new ArrayList<String>(bookingService.getFreeVIPSeats(action31)).get(0)));
        System.out.println(bookingService.bookTicket(action31, user1,
                new ArrayList<String>(bookingService.getFreeVIPSeats(action31)).get(0)));
        System.out.println(bookingService.bookTicket(action31, user1,
                new ArrayList<String>(bookingService.getFreeVIPSeats(action31)).get(0)));
        System.out.println(bookingService.bookTicket(action31, user2,
                new ArrayList<String>(bookingService.getFreeVIPSeats(action31)).get(0)));
        System.out.println(bookingService.getFreeVIPSeats(action31));

        System.out.println(bookingService.getFreeSeats(action12));
        System.out.println(bookingService.bookTicket(action12, user2, new ArrayList<String>(bookingService.getFreeSeats(action12)).get(0)));
        System.out.println(bookingService.bookTicket(action12, user2, new ArrayList<String>(bookingService.getFreeSeats(action12)).get(0)));
        System.out.println(bookingService.bookTicket(action12, user2, new ArrayList<String>(bookingService.getFreeSeats(action12)).get(0)));
        System.out.println(bookingService.bookTicket(action12, user2, new ArrayList<String>(bookingService.getFreeSeats(action12)).get(0)));
        System.out.println(bookingService.bookTicket(action12, user2, new ArrayList<String>(bookingService.getFreeSeats(action12)).get(0)));
        System.out.println(bookingService.getFreeSeats(action12));

        System.out.println(bookingService.getFreeSeats(action22));
        System.out.println(bookingService.bookTicket(action22, user2, new ArrayList<String>(bookingService.getFreeSeats(action22)).get(0)));
        System.out.println(bookingService.bookTicket(action22, user2, new ArrayList<String>(bookingService.getFreeSeats(action22)).get(0)));
        System.out.println(bookingService.bookTicket(action22, user2, new ArrayList<String>(bookingService.getFreeSeats(action22)).get(0)));
        System.out.println(bookingService.bookTicket(action22, user2, new ArrayList<String>(bookingService.getFreeSeats(action22)).get(0))
                + " !!!");
        System.out.println(bookingService.bookTicket(action22, user2, new ArrayList<String>(bookingService.getFreeSeats(action22)).get(0)));
        System.out.println(bookingService.bookTicket(action22, user2, new ArrayList<String>(bookingService.getFreeSeats(action22)).get(0)));
        System.out.println(bookingService.getFreeSeats(action22));

        System.out.println(bookingService.bookTicket(action11, user2, new ArrayList<String>(bookingService.getFreeSeats(action11)).get(0)));
        System.out.println(bookingService.bookTicket(action11, user2, new ArrayList<String>(bookingService.getFreeSeats(action11)).get(0)));
        System.out.println(bookingService.bookTicket(action11, user2, new ArrayList<String>(bookingService.getFreeSeats(action11)).get(0)));
        System.out.println(bookingService.bookTicket(action11, user2, new ArrayList<String>(bookingService.getFreeSeats(action11)).get(0)));
        System.out.println(bookingService.bookTicket(action11, user2, new ArrayList<String>(bookingService.getFreeSeats(action11)).get(0)));
        System.out.println(bookingService.bookTicket(action12, user2, new ArrayList<String>(bookingService.getFreeSeats(action12)).get(0)));
        System.out.println(bookingService.bookTicket(action12, user2, new ArrayList<String>(bookingService.getFreeSeats(action12)).get(0)));
        System.out.println(bookingService.bookTicket(action12, user2, new ArrayList<String>(bookingService.getFreeSeats(action12)).get(0))
                + " !!!");
        System.out.println(bookingService.bookTicket(action12, user2, new ArrayList<String>(bookingService.getFreeSeats(action12)).get(0)));
        System.out.println(bookingService.bookTicket(action23, user2, new ArrayList<String>(bookingService.getFreeSeats(action23)).get(0)));
        System.out.println(bookingService.bookTicket(action23, user2, new ArrayList<String>(bookingService.getFreeSeats(action23)).get(0)));

        System.out.println(eventService.getEventsByRating(EventRating.HIGH));

        System.out.println("============ Task 2 ===============");

        System.out.println(eventService.getEventByName("Star wars"));
        System.out.println(eventService.getEventByName("Star wars"));
        System.out.println(eventService.getEventByName("Star wars"));
        System.out.println(eventService.getEventByName("Titanic"));

        System.out.println(bookingService.getTicketPrice(action11, new ArrayList<String>(bookingService.getFreeSeats(action11)).get(0)));
        System.out.println(bookingService.getTicketPrice(action21, new ArrayList<String>(bookingService.getFreeSeats(action21)).get(0)));
        System.out.println(bookingService.getTicketPrice(action22, new ArrayList<String>(bookingService.getFreeSeats(action22)).get(0)));

        System.out.println(bookingService.getDiscountedTicketPrice(action11,
                new ArrayList<String>(bookingService.getFreeSeats(action11)).get(0), user1));
        System.out.println(bookingService.getDiscountedTicketPrice(action21,
                new ArrayList<String>(bookingService.getFreeSeats(action21)).get(0), user1));
        System.out.println(bookingService.getDiscountedTicketPrice(action22,
                new ArrayList<String>(bookingService.getFreeSeats(action22)).get(0), user1));

        AfishaDAOFactory daof = (AfishaDAOFactory) ctx.getBean("dao");
        System.out.println("--- event statistics ----");
        for (EventStatistics stat : daof.getAfishaDAOEventStatistics().getAll()) {
            System.out.println(stat);
        }

        System.out.println("\n--- discount statistics ----");
        for (DiscountStatistics stat : daof.getAfishaDAODiscountStatistics().getAll()) {
            System.out.println(stat);
        }
        DiscountAspect discountAspect = (DiscountAspect) ctx.getBean("discountAspect");
        System.out.println("total = " + discountAspect.getTotalCount());

        ((ConfigurableApplicationContext) ctx).close();// TODO: nice to close it
    }
}

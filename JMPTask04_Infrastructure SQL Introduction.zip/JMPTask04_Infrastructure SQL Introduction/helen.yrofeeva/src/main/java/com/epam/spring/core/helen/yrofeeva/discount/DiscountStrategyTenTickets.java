package com.epam.spring.core.helen.yrofeeva.discount;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.epam.spring.core.helen.yrofeeva.dto.EventAction;
import com.epam.spring.core.helen.yrofeeva.dto.Ticket;
import com.epam.spring.core.helen.yrofeeva.dto.User;
import com.epam.spring.core.helen.yrofeeva.services.BookingService;

/**
 * calculate discount every Number booked tickets
 */
@Service
public class DiscountStrategyTenTickets implements DiscountStrategy {
    private BookingService bookingService;
    private int discountNumber;
    private double discountCoeff;

    @Autowired
    public void setBookingService(BookingService bookingService) {
        this.bookingService = bookingService;
    }

    @Value("${discountTicket.Number}")
    public void setDiscountNumber(int discountNumber) {
        this.discountNumber = discountNumber;
    }

    @Value("${discountTicket.Value}")
    public void setDiscountCoeff(double discount) {
        this.discountCoeff = discount;
    }

    @Override
    public double getDiscountCoeff(EventAction action, User user) {
        Collection<Ticket> tickets = bookingService.getUserBookedTickets(user);
        // TODO: still little issue, strategy is to provide discount in case user is buying Nth ticket.
        // TODO: you do now providing discount in case user is buying N+1th ticket. also,
        // TODO: there is edge case if user didn't buy any one.. In that case you provide discount also.. Good for business but not for task
        // %)
        // ok
        if (tickets.size() > 0 && ((tickets.size() + 1) % discountNumber) == 0) {
            return discountCoeff;
        }
        return 1;
    }

}

package com.epam.spring.core.helen.yrofeeva.services.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;

import com.epam.spring.core.helen.yrofeeva.dao.AfishaDAOFactory;
import com.epam.spring.core.helen.yrofeeva.dto.EventAction;
import com.epam.spring.core.helen.yrofeeva.dto.Ticket;
import com.epam.spring.core.helen.yrofeeva.dto.User;
import com.epam.spring.core.helen.yrofeeva.services.AuditoriumService;
import com.epam.spring.core.helen.yrofeeva.services.BookingService;
import com.epam.spring.core.helen.yrofeeva.services.DiscountService;

public class BookingServiceImpl implements BookingService {
    private AfishaDAOFactory dao;
    private AuditoriumService auditoriumService;
    private DiscountService discountService;

    public BookingServiceImpl() {
    }

    @Autowired
    public BookingServiceImpl(AfishaDAOFactory dao) {
        this.dao = dao;
    }

    @Autowired
    public void setAuditoriumService(AuditoriumService auditoriumService) {
        this.auditoriumService = auditoriumService;
    }

    @Autowired
    public void setDiscountService(DiscountService discountService) {
        this.discountService = discountService;
    }

    //TODO: I thought you need to apply discount for price also. In the original task the method signature is 'getTicketPrice(event, date, time, seats, user)'. Need to update.
    // введена новая сущность EventAction которая содержит event, date, time + auditorium
    @Override
    public double getTicketPrice(EventAction eventAction, String seat) {
        double price = dao.getAfishaDAOEvent().getEntity(eventAction.getEventID()).getPrice();
        if (auditoriumService.getVipSeats().contains(seat)) {
            price = price * auditoriumService.getVIPCoeff();
        }
        return price;
    }
    
    //TODO: would be nice to apply real price to the ticket
    /**
     * discounted price
     */
    @Override
    public double getDiscountedTicketPrice(EventAction eventAction, String seat, User user) {
        double price = getTicketPrice(eventAction, seat);
        double discount = discountService.getDiscount(eventAction, user);
        return price*discount;
    }
    
    @Override
    public Collection<Ticket> getTickets(EventAction eventAction) {
        Collection<Ticket> tickets = dao.getAfishaDAOTicket().getAll();
        Collection<Ticket> res = new ArrayList<>();//TODO: don't use 'res', use readable name 'result'
        for (Ticket t : tickets) {
            if (t.getEventActionID() == eventAction.getId()) {
                res.add(t);
            }
        }
        return res;
    }

    //TODO: I don't see real price (include discount) in the ticket, only separate price and discount (which might be strange '1' value).
    @Override
    public Ticket bookTicket(EventAction eventAction, User user, String seat) {
        Ticket ticket = null;
        if (!getBookedSeats(eventAction).contains(seat)) {//TODO: why so hard? is it not easier if just check seat into getBookedSeats?? O_O //HY: corrected
            double price = getTicketPrice(eventAction, seat);
            double discount = discountService.getDiscount(eventAction, user);
            //double discountedPrice = getDiscountedTicketPrice(eventAction, seat, user);
            ticket = new Ticket(dao.getAfishaDAOTicket().getMaxId() + 1, eventAction.getId(), user.getId(), seat, price, discount);
            dao.getAfishaDAOTicket().add(ticket);
        }
        return ticket;
    }

    @Override
    public Collection<String> getFreeSeats(EventAction eventAction) {
        Set<String> seats = auditoriumService.getSeats();
        return getFreeSeats(eventAction, seats);
    }

    @Override
    public Collection<String> getFreeVIPSeats(EventAction eventAction) {
        Set<String> seats = auditoriumService.getVipSeats();
        return getFreeSeats(eventAction, seats);
    }

    @Override
    public Collection<String> getBookedSeats(EventAction eventAction) {
        Collection<String> res = new HashSet<>();
        Collection<Ticket> tickets = dao.getAfishaDAOTicket().getAll();
        for (Ticket t : tickets) {
            if (t.getEventActionID() == eventAction.getId()) {
                res.add(t.getSeat());
            }
        }
        return res;
    }

    private Collection<String> getFreeSeats(EventAction eventAction, Set<String> seats) {
        Collection<String> booked = getBookedSeats(eventAction);
        Collection<String> res = new HashSet<>();
        for (String seat : seats) {
            if (!booked.contains(seat)) {
                res.add(seat);
            }
        }
        return res;
    }

    @Override
    public Collection<Ticket> getUserBookedTickets(User user) {
        Collection<Ticket> tic = dao.getAfishaDAOTicket().getAll();
        Collection<Ticket> res = new ArrayList<>();
        for (Ticket t : tic) {
            if (t.getUserID() == user.getId()) {
                res.add(t);
            }
        }
        return res;
    }
}

package com.epam.spring.core.helen.yrofeeva.services;

import java.util.Set;

public interface AuditoriumService {
    Set<String> getSeats();
    Set<String> getVipSeats();
    double getVIPCoeff();
}

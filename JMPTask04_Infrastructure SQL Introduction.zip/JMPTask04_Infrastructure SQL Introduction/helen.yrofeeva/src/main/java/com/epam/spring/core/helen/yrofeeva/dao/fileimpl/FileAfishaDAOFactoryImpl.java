package com.epam.spring.core.helen.yrofeeva.dao.fileimpl;

import org.springframework.beans.factory.annotation.Value;

import com.epam.spring.core.helen.yrofeeva.dao.AfishaDAO;
import com.epam.spring.core.helen.yrofeeva.dao.AfishaDAOFactory;
import com.epam.spring.core.helen.yrofeeva.dto.DiscountStatistics;
import com.epam.spring.core.helen.yrofeeva.dto.Event;
import com.epam.spring.core.helen.yrofeeva.dto.EventAction;
import com.epam.spring.core.helen.yrofeeva.dto.EventStatistics;
import com.epam.spring.core.helen.yrofeeva.dto.Ticket;
import com.epam.spring.core.helen.yrofeeva.dto.User;

public class FileAfishaDAOFactoryImpl implements AfishaDAOFactory{
    @Value("${userPath}")
    private String userPath;
    @Value("${eventPath}")
    private String eventPath;
    @Value("${eventActionPath}")
    private String eventActionPath;
    @Value("${ticketPath}")
    private String ticketPath;
    
    @Value("${eventStatistics}")
    private String eventStatisticsPath;
    @Value("${discountStatistics}")
    private String discountStatisticsPath;

    private AfishaDAO<User> afishaDAOUser; 
    private AfishaDAO<Event> afishaDAOEvent; 
    private AfishaDAO<EventAction> afishaDAOEventAction; 
    private AfishaDAO<Ticket> afishaDAOTicket; 
    
    private AfishaDAO<EventStatistics> afishaDAOEventStatistics; 
    private AfishaDAO<DiscountStatistics> afishaDAODiscountStatistics; 
    
    private FileAfishaDAOFactoryImpl(){
        afishaDAOUser = new FileAfishaDAOImpl<User>(userPath); 
        afishaDAOEvent = new FileAfishaDAOImpl<Event>(eventPath); 
        afishaDAOEventAction = new FileAfishaDAOImpl<EventAction>(eventActionPath); 
        afishaDAOTicket = new FileAfishaDAOImpl<Ticket>(ticketPath); 
        
        afishaDAOEventStatistics = new FileAfishaDAOImpl<EventStatistics>(eventStatisticsPath);
        afishaDAODiscountStatistics = new FileAfishaDAOImpl<DiscountStatistics>(discountStatisticsPath);
    }

    @Override
    public AfishaDAO<User> getAfishaDAOUser() {
        return afishaDAOUser;
    }

    @Override
    public AfishaDAO<Event> getAfishaDAOEvent() {
        return afishaDAOEvent;
    }

    @Override
    public AfishaDAO<EventAction> getAfishaDAOEventAction() {
        return afishaDAOEventAction;
    }

    @Override
    public AfishaDAO<Ticket> getAfishaDAOTicket() {
        return afishaDAOTicket;
    }

    @Override
    public AfishaDAO<EventStatistics> getAfishaDAOEventStatistics() {
        return afishaDAOEventStatistics;
    }

    @Override
    public AfishaDAO<DiscountStatistics> getAfishaDAODiscountStatistics() {
        return afishaDAODiscountStatistics;
    }

}

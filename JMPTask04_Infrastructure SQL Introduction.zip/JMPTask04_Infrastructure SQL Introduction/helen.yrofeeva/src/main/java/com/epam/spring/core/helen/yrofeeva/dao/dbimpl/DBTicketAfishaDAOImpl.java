package com.epam.spring.core.helen.yrofeeva.dao.dbimpl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.epam.spring.core.helen.yrofeeva.dao.AfishaDAO;
import com.epam.spring.core.helen.yrofeeva.dto.Ticket;

public class DBTicketAfishaDAOImpl implements AfishaDAO<Ticket>{
    protected  JdbcTemplate jdbcTemplate;
    private static final String SQL_ADD = "INSERT INTO Tickets (ID, eventActionID, userID, seat, price, lucky) VALUES (?,?,?,?,?,?)"; 
    private static final String SQL_DELETE = "DELETE FROM Tickets WHERE ID = ?"; 
    private static final String SQL_DELETE_ALL = "DELETE FROM Tickets"; 
    private static final String SQL_SELECT = "SELECT ID, eventActionID, userID, seat, price, lucky FROM Tickets WHERE ID = ?"; 
    private static final String SQL_SELECT_ALL = "SELECT ID, eventActionID, userID, seat, price, lucky FROM Tickets"; 
    private static final String SQL_MAX_ID = "SELECT MAX(ID) AS maxID FROM Tickets"; 
    
    public DBTicketAfishaDAOImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private Ticket fillEntity(ResultSet rs) throws SQLException {
        Ticket entity = new Ticket();
        entity.setId(rs.getInt("ID"));
        entity.setEventActionID(rs.getInt("eventActionID"));
        entity.setUserID(rs.getInt("userID"));
        entity.setSeat(rs.getString("seat"));
        entity.setPrice(rs.getDouble("price"));
        entity.setLucky(rs.getBoolean("lucky"));
        return entity;
    }

    @Override
    public Ticket getEntity(int id) {
        Ticket entity = jdbcTemplate.queryForObject(SQL_SELECT, new Object[] { id }, new RowMapper<Ticket>() {
            public Ticket mapRow(ResultSet rs, int rowNum) throws SQLException {
                return fillEntity(rs);
            }
        });
        return entity;
    }

    @Override
    public Collection<Ticket> getAll() {
        List<Ticket> all = jdbcTemplate.query(SQL_SELECT_ALL, new RowMapper<Ticket>() {
            public Ticket mapRow(ResultSet rs, int rowNum) throws SQLException {
                return fillEntity(rs);
            }
        });
        return all;
    }

    @Override
    public void add(Ticket e) {
        jdbcTemplate.update(SQL_ADD, e.getId(), e.getEventActionID(), e.getUserID(), e.getSeat(), e.getPrice(), e.isLucky());
    }

    @Override
    public void remove(Ticket e) {
        jdbcTemplate.update(SQL_DELETE, e.getId());
    }

    @Override
    public int getMaxId() {
        try {
            return jdbcTemplate.queryForObject(SQL_MAX_ID, Integer.class);
        } catch (Exception e) {
            return 0;
        }
    }

    @Override
    public void removeAll() {
        jdbcTemplate.update(SQL_DELETE_ALL);
    }

    @Override
    public void update(Ticket e) {
        // TODO Auto-generated method stub
        
    }

}

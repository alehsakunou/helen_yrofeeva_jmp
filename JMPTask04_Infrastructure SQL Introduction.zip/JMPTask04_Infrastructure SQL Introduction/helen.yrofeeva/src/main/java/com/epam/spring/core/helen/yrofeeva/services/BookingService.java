package com.epam.spring.core.helen.yrofeeva.services;

import java.util.Collection;

import com.epam.spring.core.helen.yrofeeva.dto.EventAction;
import com.epam.spring.core.helen.yrofeeva.dto.Ticket;
import com.epam.spring.core.helen.yrofeeva.dto.User;

public interface BookingService {
    double getTicketPrice(EventAction eventAction, String seat);
    double getDiscountedTicketPrice(EventAction eventAction, String seat, User user);
    Collection<Ticket> getTickets(EventAction eventAction);
    /**
     * book the ticket
     * @param eventAction event action object (event in auditorium for date-time)
     * @param user user object
     * @param seat seat number
     * @return ticket object or null if requested seat already booked
     */
    Ticket bookTicket(EventAction eventAction, User user, String seat);
    Collection<String> getFreeSeats(EventAction eventAction);
    Collection<String> getFreeVIPSeats(EventAction eventAction);
    Collection<String> getBookedSeats(EventAction eventAction);
    /** return all tickets booked by user */
    // better to accommodate this method here instead of userService
    Collection<Ticket> getUserBookedTickets(User user);
}

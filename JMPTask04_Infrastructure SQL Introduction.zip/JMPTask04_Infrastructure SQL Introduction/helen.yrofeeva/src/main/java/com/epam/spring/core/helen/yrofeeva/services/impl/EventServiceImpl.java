package com.epam.spring.core.helen.yrofeeva.services.impl;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;

import com.epam.spring.core.helen.yrofeeva.dao.AfishaDAOFactory;
import com.epam.spring.core.helen.yrofeeva.dto.Event;
import com.epam.spring.core.helen.yrofeeva.dto.EventRating;
import com.epam.spring.core.helen.yrofeeva.services.EventService;

public class EventServiceImpl implements EventService {
    private AfishaDAOFactory dao;
    
    public EventServiceImpl() {
    }

    @Autowired
    public EventServiceImpl(AfishaDAOFactory dao) {
        this.dao = dao;
    }

    @Override
    public void addEvent(Event event) {
        dao.getAfishaDAOEvent().add(event);
    }

    @Override
    public void removeEvent(Event event) {
        dao.getAfishaDAOEvent().remove(event);
    }

    @Override
    public Collection<Event> getEventsByRating(EventRating rating) {
        Collection<Event> coll = dao.getAfishaDAOEvent().getAll();
        Collection<Event> res = new ArrayList<>();

        for (Event ev : coll) {
            if (ev.getRating().equals(rating)) {
                res.add(ev);
            }
        }
        return res;
    }

    @Override
    public Event getEventByName(String name) {
        Collection<Event> coll = dao.getAfishaDAOEvent().getAll();
        for (Event ev : coll) {
            if (ev.getName().equals(name)) {
                return ev;
            }
        }
        return null;
    }

    @Override
    public Event getEventById(int eventID) {
        return dao.getAfishaDAOEvent().getEntity(eventID);
    }

}

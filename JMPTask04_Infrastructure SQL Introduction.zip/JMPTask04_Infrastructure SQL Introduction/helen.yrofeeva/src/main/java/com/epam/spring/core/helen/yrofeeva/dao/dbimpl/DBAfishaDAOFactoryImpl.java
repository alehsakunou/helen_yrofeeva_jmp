package com.epam.spring.core.helen.yrofeeva.dao.dbimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import com.epam.spring.core.helen.yrofeeva.dao.AfishaDAO;
import com.epam.spring.core.helen.yrofeeva.dao.AfishaDAOFactory;
import com.epam.spring.core.helen.yrofeeva.dto.DiscountStatistics;
import com.epam.spring.core.helen.yrofeeva.dto.Event;
import com.epam.spring.core.helen.yrofeeva.dto.EventAction;
import com.epam.spring.core.helen.yrofeeva.dto.EventStatistics;
import com.epam.spring.core.helen.yrofeeva.dto.Ticket;
import com.epam.spring.core.helen.yrofeeva.dto.User;

public class DBAfishaDAOFactoryImpl implements AfishaDAOFactory{
    private AfishaDAO<User> afishaDAOUser; 
    private AfishaDAO<Event> afishaDAOEvent; 
    private AfishaDAO<EventAction> afishaDAOEventAction; 
    private AfishaDAO<Ticket> afishaDAOTicket; 
    
    private AfishaDAO<EventStatistics> afishaDAOEventStatistics; 
    private AfishaDAO<DiscountStatistics> afishaDAODiscountStatistics; 
    
    @Autowired
    private DBAfishaDAOFactoryImpl(JdbcTemplate jdbcTemplate) {
        afishaDAOUser = new DBUserAfishaDAOImpl(jdbcTemplate); 
        afishaDAOEvent = new DBEventAfishaDAOImpl(jdbcTemplate); 
        afishaDAOEventAction = new DBEventActionAfishaDAOImpl(jdbcTemplate); 
        afishaDAOTicket = new DBTicketAfishaDAOImpl(jdbcTemplate); 
        
        afishaDAOEventStatistics = new DBEventStatAfishaDAOImpl(jdbcTemplate);
        afishaDAODiscountStatistics = new DBDiscountStatAfishaDAOImpl(jdbcTemplate);
    }
    
    @Override
    public AfishaDAO<User> getAfishaDAOUser() {
        return afishaDAOUser;
    }

    @Override
    public AfishaDAO<Event> getAfishaDAOEvent() {
        return afishaDAOEvent;
    }

    @Override
    public AfishaDAO<EventAction> getAfishaDAOEventAction() {
        return afishaDAOEventAction;
    }

    @Override
    public AfishaDAO<Ticket> getAfishaDAOTicket() {
        return afishaDAOTicket;
    }

    @Override
    public AfishaDAO<EventStatistics> getAfishaDAOEventStatistics() {
        return afishaDAOEventStatistics;
    }

    @Override
    public AfishaDAO<DiscountStatistics> getAfishaDAODiscountStatistics() {
        return afishaDAODiscountStatistics;
    }

}

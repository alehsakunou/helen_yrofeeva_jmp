package com.epam.spring.core.helen.yrofeeva.services.impl;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;

import com.epam.spring.core.helen.yrofeeva.dao.AfishaDAOFactory;
import com.epam.spring.core.helen.yrofeeva.dto.User;
import com.epam.spring.core.helen.yrofeeva.services.UserService;

public class UserServiceImpl implements UserService {
    private AfishaDAOFactory dao;

    public UserServiceImpl() {
    }

    @Autowired
    public UserServiceImpl(AfishaDAOFactory dao) {
        this.dao = dao;
    }

    @Override
    public void registerUser(User user) {
        dao.getAfishaDAOUser().add(user);
    }

    @Override
    public void removeUser(User user) {
        dao.getAfishaDAOUser().remove(user);
    }

    @Override
    public User getUserByName(String name) {
        Collection<User> coll = dao.getAfishaDAOUser().getAll();
        for (User user : coll) {
            if (name.equals(user.getName())) {
                return user;
            }
        }
        return null;
    }

    @Override
    public User getUserById(int userID) {
        return dao.getAfishaDAOUser().getEntity(userID);
    }

    @Override
    public User getUserByEmail(String email) {
        Collection<User> coll = dao.getAfishaDAOUser().getAll();
        for (User user : coll) {
            if (email.equals(user.getEmail())) {
                return user;
            }
        }
        return null;
    }

}

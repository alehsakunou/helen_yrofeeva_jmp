package com.epam.spring.core.helen.yrofeeva.services;

import com.epam.spring.core.helen.yrofeeva.dto.EventAction;
import com.epam.spring.core.helen.yrofeeva.dto.User;

public interface DiscountService {
    double getDiscount(EventAction action, User user);
}

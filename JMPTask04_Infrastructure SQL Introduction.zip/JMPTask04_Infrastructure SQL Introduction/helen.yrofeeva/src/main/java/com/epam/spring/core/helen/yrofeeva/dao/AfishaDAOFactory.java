package com.epam.spring.core.helen.yrofeeva.dao;

import com.epam.spring.core.helen.yrofeeva.dto.DiscountStatistics;
import com.epam.spring.core.helen.yrofeeva.dto.Event;
import com.epam.spring.core.helen.yrofeeva.dto.EventAction;
import com.epam.spring.core.helen.yrofeeva.dto.EventStatistics;
import com.epam.spring.core.helen.yrofeeva.dto.Ticket;
import com.epam.spring.core.helen.yrofeeva.dto.User;

public interface AfishaDAOFactory {
    AfishaDAO<User> getAfishaDAOUser();
    AfishaDAO<Event> getAfishaDAOEvent();
    AfishaDAO<EventAction> getAfishaDAOEventAction();
    AfishaDAO<Ticket> getAfishaDAOTicket();
    // task2
    AfishaDAO<EventStatistics> getAfishaDAOEventStatistics();
    AfishaDAO<DiscountStatistics> getAfishaDAODiscountStatistics();
}

package com.epam.spring.core.helen.yrofeeva.dao.dbimpl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.epam.spring.core.helen.yrofeeva.dao.AfishaDAO;
import com.epam.spring.core.helen.yrofeeva.dto.EventStatistics;

public class DBEventStatAfishaDAOImpl implements AfishaDAO<EventStatistics>{
    protected  JdbcTemplate jdbcTemplate;
    private static final String SQL_ADD = "INSERT INTO EventStatistics (ID, eventID, accessByName, pricesWereQueried, ticketsWereBooked) VALUES (?,?,?,?,?)"; 
    private static final String SQL_DELETE = "DELETE FROM EventStatistics WHERE ID = ?"; 
    private static final String SQL_DELETE_ALL = "DELETE FROM EventStatistics"; 
    private static final String SQL_SELECT = "SELECT ID, eventID, accessByName, pricesWereQueried, ticketsWereBooked FROM EventStatistics WHERE ID = ?"; 
    private static final String SQL_SELECT_ALL = "SELECT ID, eventID, accessByName, pricesWereQueried, ticketsWereBooked FROM EventStatistics"; 
    private static final String SQL_MAX_ID = "SELECT MAX(ID) AS maxID FROM EventStatistics"; 
    private static final String SQL_UPDATE = "UPDATE EventStatistics SET eventID = ?, accessByName = ?, pricesWereQueried = ?, ticketsWereBooked = ? WHERE ID = ?"; 
    
    public DBEventStatAfishaDAOImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }
    
    private EventStatistics fillEntity(ResultSet rs) throws SQLException {
        EventStatistics entity = new EventStatistics();
        entity.setId(rs.getInt("ID"));
        entity.setEventID(rs.getInt("eventID"));
        entity.setAccessByName(rs.getInt("accessByName"));
        entity.setPricesWereQueried(rs.getInt("pricesWereQueried"));
        entity.setTicketsWereBooked(rs.getInt("ticketsWereBooked"));
        return entity;
    }
    
    @Override
    public EventStatistics getEntity(int id) {
        EventStatistics entity = jdbcTemplate.queryForObject(SQL_SELECT, new Object[] { id }, new RowMapper<EventStatistics>() {
            public EventStatistics mapRow(ResultSet rs, int rowNum) throws SQLException {
                return fillEntity(rs);
            }
        });
        return entity;
    }

    @Override
    public Collection<EventStatistics> getAll() {
        List<EventStatistics> all = jdbcTemplate.query(SQL_SELECT_ALL, new RowMapper<EventStatistics>() {
            public EventStatistics mapRow(ResultSet rs, int rowNum) throws SQLException {
                return fillEntity(rs);
            }
        });
        return all;
    }

    @Override
    public void add(EventStatistics e) {
        jdbcTemplate.update(SQL_ADD, e.getId(), e.getEventID(), e.getAccessByName(), e.getPricesWereQueried(), e.getTicketsWereBooked());
    }

    @Override
    public void remove(EventStatistics e) {
        jdbcTemplate.update(SQL_DELETE, e.getId());
    }

    @Override
    public int getMaxId() {
        try {
            return jdbcTemplate.queryForObject(SQL_MAX_ID, Integer.class);
        } catch (Exception e) {
            return 0;
        }
    }

    @Override
    public void removeAll() {
        jdbcTemplate.update(SQL_DELETE_ALL);
    }

    @Override
    public void update(EventStatistics e) {
        jdbcTemplate.update(SQL_UPDATE, e.getEventID(), e.getAccessByName(), e.getPricesWereQueried(), e.getTicketsWereBooked(), e.getId());
    }

}

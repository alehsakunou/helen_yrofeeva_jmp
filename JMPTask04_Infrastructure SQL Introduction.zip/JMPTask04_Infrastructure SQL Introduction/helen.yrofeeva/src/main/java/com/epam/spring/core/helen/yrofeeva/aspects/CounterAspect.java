package com.epam.spring.core.helen.yrofeeva.aspects;

import java.util.Collection;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;

import com.epam.spring.core.helen.yrofeeva.dao.AfishaDAOFactory;
import com.epam.spring.core.helen.yrofeeva.dto.Event;
import com.epam.spring.core.helen.yrofeeva.dto.EventAction;
import com.epam.spring.core.helen.yrofeeva.dto.EventStatistics;

@Aspect
public class CounterAspect {
    private AfishaDAOFactory dao;

    // approach with using field (to transfer object between methods) will work in single thread app..
    // for multithread app maybe it needs to put CounterAspect to scope="prototype" ?
    // private EventStatistics eventStatistics;

    @Autowired
    public void setDao(AfishaDAOFactory dao) {
        this.dao = dao;
    }

    private EventStatistics getStatisticsByEventID(int id) {
        Collection<EventStatistics> c = dao.getAfishaDAOEventStatistics().getAll();
        for (EventStatistics evst : c) {
            if (evst.getEventID() == id) {
                return evst;
            }
        }
        // need to create new statistics object (there is no statistics object for event)
        EventStatistics evst = new EventStatistics();
        evst.setId(dao.getAfishaDAOEventStatistics().getMaxId() + 1);
        evst.setEventID(id);
        dao.getAfishaDAOEventStatistics().add(evst);
        return evst;
    }

    // TODO: would be better to add at least class name
    /* public Event getEventByName(String name) */
    @Pointcut("execution(* *.getEventByName(..))")
    private void getEventByNameMethods() {
    }

    @AfterReturning(pointcut = "getEventByNameMethods()", returning = "retVal")
    public void countEventByName(Object retVal) {
        if (retVal != null) {
            Event retEv = (Event) retVal;
            EventStatistics eventStatistics = getStatisticsByEventID(retEv.getId());
            // TODO: don't need to check for NULL if your method return always object
            // if (eventStatistics != null)
            // TODO: HINT: bad practice to not use block { } in 1 row body code. Using { } increase readability and easy supporting if you
            // need to add other row
            eventStatistics.setAccessByName(eventStatistics.getAccessByName() + 1);
            dao.getAfishaDAOEventStatistics().update(eventStatistics);
        }
    }

    @Around("execution(* *.*TicketPrice(..))")
    public Object countGetTicketPrice(ProceedingJoinPoint joinPoint) throws Throwable {
        Object[] args = joinPoint.getArgs();
        EventAction act = (EventAction) args[0];
        Object result;
        try {

            result = joinPoint.proceed(args);

            EventStatistics eventStatistics = getStatisticsByEventID(act.getEventID());
            eventStatistics.setPricesWereQueried(eventStatistics.getPricesWereQueried() + 1);
            dao.getAfishaDAOEventStatistics().update(eventStatistics);
        } catch (Throwable t) {
            // log should be here
            throw t;
        }
        return result;
    }
    
    @Around("execution(* *.bookTicket(..))")
    public Object countBookTicket(ProceedingJoinPoint joinPoint) throws Throwable {
        Object[] args = joinPoint.getArgs();
        EventAction act = (EventAction) args[0];
        Object result;
        try {

            result = joinPoint.proceed(args);

            EventStatistics eventStatistics = getStatisticsByEventID(act.getEventID());
            eventStatistics.setTicketsWereBooked(eventStatistics.getTicketsWereBooked() + 1);
            dao.getAfishaDAOEventStatistics().update(eventStatistics);
        } catch (Throwable t) {
            // log should be here
            throw t;
        }
        return result;
    }

    //
    // //TODO: it's better to have pointcut by full methods name with &&
    // /* BookingService
    // * double getTicketPrice(EventAction eventAction, String seat)
    // * double getDiscountedTicketPrice(EventAction eventAction, String seat, User user); */
    // @Pointcut("execution(* *.*TicketPrice(..))")
    // private void getTicketPriceMethods() {
    // }
    //
    // //TODO: HINT, better have arguments in pointcut, to not catch issues in future
    // @Before("getTicketPriceMethods()")
    // public void beforeGetTicketPrice(JoinPoint joinPoint) {
    // EventAction act = (EventAction)joinPoint.getArgs()[0];//TODO: cause no guaranty that method will be changed or added new one with
    // different argument
    // eventStatistics = getStatisticsByEventID(act.getEventID());
    // //TODO: where calculation? O_o
    // }
    //
    // @AfterReturning(pointcut = "getTicketPriceMethods()", returning = "retVal")
    // public void countGetTicketPrice(Object retVal) {
    // //TODO: bad bad bad.. and not cause it's not Around.
    // //TODO: cause you could use it nice event with After, if you could get argument here!
    // //TODO: i.e. you don't need to have beforeGetTicketPrice at all.
    // if (eventStatistics != null)//TODO: why you need this check? It will be always some object, event from other thread
    // eventStatistics.setPricesWereQueried(eventStatistics.getPricesWereQueried() + 1);
    // }
    //
    // //TODO: better to have at least class name
    // /* public Ticket bookTicket(EventAction eventAction, User user, String seat) */
    // @Pointcut("execution(* *.bookTicket(..))")
    // private void bookTicketMethods() {
    // }
    //
    // //TODO: same issues as with previous
    // @Before("bookTicketMethods()")
    // public void beforeBookTicket(JoinPoint joinPoint) {
    // // I know that this is bad approach to get particular argument, but I didn't have enough time
    // EventAction act = (EventAction)joinPoint.getArgs()[0];
    // eventStatistics = getStatisticsByEventID(act.getEventID());
    // }
    //
    // @AfterReturning(pointcut = "bookTicketMethods()", returning = "retVal")
    // public void countBookTicket(Object retVal) {
    // if (eventStatistics != null)
    // eventStatistics.setTicketsWereBooked(eventStatistics.getTicketsWereBooked() + 1);
    // }

}

package com.epam.spring.core.helen.yrofeeva.dao.fileimpl;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeSet;

import javax.annotation.PreDestroy;

import com.epam.spring.core.helen.yrofeeva.dao.AfishaDAO;
import com.epam.spring.core.helen.yrofeeva.dto.ObjectDTO;

public class FileAfishaDAOImpl<E extends ObjectDTO> implements AfishaDAO<E> {
    private String savePath;
    private Map<Integer, E> map = new HashMap<Integer, E>();

    public FileAfishaDAOImpl(String savePath) {
        super();
        this.savePath = savePath;
    }

    @SuppressWarnings("unchecked")
    // @PostConstruct
    // аннотация закомментирована поскольку все объекты создаются каждый раз при запуске приложения,
    // т.е. не нужно их загружать (во избежание дублирования хардкодных ключей)
    public void open() {
        try {
            FileInputStream fileIn = new FileInputStream(savePath);
            ObjectInputStream in = new ObjectInputStream(fileIn);
            map = (Map<Integer, E>) in.readObject();
            in.close();
            fileIn.close();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    /**
     * save data
     */
    @PreDestroy
    public void close() {
        try {
            FileOutputStream fileOut = new FileOutputStream(savePath);
            ObjectOutputStream out = new ObjectOutputStream(fileOut);
            out.writeObject(map);
            out.close();
            fileOut.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public E getEntity(int id) {
        return map.get(id);
    }

    @Override
    public Collection<E> getAll() {
        return map.values();
    }

    @Override
    public void add(E e) {
        map.put(e.getId(), e);
    }

    @Override
    public void remove(E e) {
        map.remove(e.getId());
    }

    @Override
    public int getMaxId() {
        TreeSet<Integer> set = new TreeSet<>(map.keySet());
        if (set.size() > 0) {
            return (Integer) set.last();
        }
        return 0;
    }

    @Override
    public void removeAll() {
        map.clear();
    }

    @Override
    public void update(E e) {
        // TODO Auto-generated method stub
    }

}

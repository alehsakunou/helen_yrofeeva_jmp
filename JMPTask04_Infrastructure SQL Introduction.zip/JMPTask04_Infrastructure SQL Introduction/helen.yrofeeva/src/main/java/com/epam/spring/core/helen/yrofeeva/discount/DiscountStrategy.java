package com.epam.spring.core.helen.yrofeeva.discount;

import com.epam.spring.core.helen.yrofeeva.dto.EventAction;
import com.epam.spring.core.helen.yrofeeva.dto.User;

public interface DiscountStrategy {
    /**
     * return raising or reducing coefficient 
     * @param action EventAction object
     * @param user User object
     * @return raising or reducing coefficient
     */
    double getDiscountCoeff(EventAction action, User user);
}

package com.epam.spring.core.helen.yrofeeva.aspects;

import java.util.Random;

import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

import com.epam.spring.core.helen.yrofeeva.dto.Ticket;

@Aspect
public class LuckyWinnerAspect {
    private Random random = new Random();

    /* public Ticket bookTicket(EventAction eventAction, User user, String seat) */
    @Pointcut("execution(* *.bookTicket(..))")
    private void bookTicketMethods() {
    }

    //TODO: it works for you now, but in real systems it would be Around better. Thus price would be set before booking and not affect some other calculations (which we don;t have in that trivial app).
    // I can't change price before, only after!!!
    @AfterReturning(pointcut = "bookTicketMethods()", returning = "retVal")
    public void luckyBookTicket(Object retVal) {
        if (retVal != null) {
            int lucky = random.nextInt(10);//TODO: 'lUcky' ^_^
            if (lucky == 5) {
                Ticket ticket = (Ticket) retVal;
                ticket.setPrice(0);
                //TODO: in task was "Store the information about this lucky event into the user object (like some system messages or so"
                System.out.println("--- Task2: lucky !!!");
                // ok ok, it's better to hold this information in ticket (because user can be lucky more than once)
                ticket.setLucky(true);
            }
        }
    }

}

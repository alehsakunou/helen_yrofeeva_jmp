package com.epam.spring.core.helen.yrofeeva.dao.dbimpl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.epam.spring.core.helen.yrofeeva.dao.AfishaDAO;
import com.epam.spring.core.helen.yrofeeva.dto.User;

public class DBUserAfishaDAOImpl implements AfishaDAO<User> {
    protected JdbcTemplate jdbcTemplate;
    private static final String SQL_ADD = "INSERT INTO Users (ID, name, email, birthday, isAdmin) VALUES (?,?,?,?,?)";
    private static final String SQL_DELETE = "DELETE FROM Users WHERE ID = ?";
    private static final String SQL_DELETE_ALL = "DELETE FROM Users";
    private static final String SQL_SELECT = "SELECT ID, name, email, birthday, isAdmin FROM Users WHERE ID = ?";
    private static final String SQL_SELECT_ALL = "SELECT ID, name, email, birthday, isAdmin FROM Users";
    private static final String SQL_MAX_ID = "SELECT MAX(ID) AS maxID FROM Users";

    public DBUserAfishaDAOImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private User fillEntity(ResultSet rs) throws SQLException {
        User entity = new User();
        entity.setId(rs.getInt("ID"));
        entity.setName(rs.getString("name").trim());
        entity.setEmail(rs.getString("email").trim());
        entity.setBirthday(rs.getDate("birthday"));
        entity.setAdmin(rs.getBoolean("isAdmin"));
        return entity;
    }

    @Override
    public User getEntity(int id) {
        User entity = jdbcTemplate.queryForObject(SQL_SELECT, new Object[] { id }, new RowMapper<User>() {
            public User mapRow(ResultSet rs, int rowNum) throws SQLException {
                return fillEntity(rs);
            }
        });
        return entity;
    }

    @Override
    public Collection<User> getAll() {
        List<User> all = jdbcTemplate.query(SQL_SELECT_ALL, new RowMapper<User>() {
            public User mapRow(ResultSet rs, int rowNum) throws SQLException {
                return fillEntity(rs);
            }
        });
        return all;
    }

    @Override
    public void add(User e) {
        jdbcTemplate.update(SQL_ADD, e.getId(), e.getName(), e.getEmail(), e.getBirthday(), e.isAdmin());
    }

    @Override
    public void remove(User e) {
        jdbcTemplate.update(SQL_DELETE, e.getId());
    }

    @Override
    public int getMaxId() {
        try {
            return jdbcTemplate.queryForObject(SQL_MAX_ID, Integer.class);
        } catch (Exception e) {
            return 0;
        }
    }

    @Override
    public void removeAll() {
        jdbcTemplate.update(SQL_DELETE_ALL);
    }

    @Override
    public void update(User e) {
        // TODO Auto-generated method stub
        
    }

}

package com.epam.spring.core.helen.yrofeeva.discount;

import java.util.Calendar;

import org.springframework.beans.factory.annotation.Value;

import com.epam.spring.core.helen.yrofeeva.dto.EventAction;
import com.epam.spring.core.helen.yrofeeva.dto.User;
/**
 * calculate discount by birthday 
 * p.s. birthday = event action day
 */
public class DiscountStrapegyBirthday implements DiscountStrategy {
    private double discount;
    
    @Value("${discountBirthday.Value}")
    public void setDiscount(double discount) {
        this.discount = discount;
    }
    
    /**
     * return coeff with should be >0 , because price will be multiplied by it
     */
    @Override
    public double getDiscountCoeff(EventAction action, User user) {
        Calendar c = Calendar.getInstance();
        c.setTime(action.getDateTimeStart());
        int month = c.get(Calendar.MONTH);
        int day = c.get(Calendar.DATE);
        c.setTime(user.getBirthday());
        int monthU = c.get(Calendar.MONTH);
        int dayU = c.get(Calendar.DATE);

        if (month == monthU && day == dayU) {
            return discount;
        }
        return 1;//TODO: why default value is 1? It looks strange, as discount means how many need to discount
        // because price will be multiplied by it
    }
    
}

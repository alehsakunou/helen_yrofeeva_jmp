package com.epam.spring.core.helen.yrofeeva.dto;

import java.io.Serializable;

/**
 * user can bye ticket for event action
 * maybe with discount
 *
 */
public class Ticket extends ObjectDTO implements Serializable {
    private static final long serialVersionUID = 1L;
    private int eventActionID;
    private int userID;
    private String seat;
    /** full price (cost) of ticket */
    private double price;
    //TODO: pretty strange logic. What is in case vip and has discount? HY: yes (I want to hold this value separately with origin price)
    /** coefficient for price can be <1 for discount and >1 for VIP seats */
    private double coeff = 1;
    private boolean lucky;

    public Ticket() {

    }

    public Ticket(int id, int eventActionID, int userID, String seat, double price, double coeff) {
        super();
        this.id = id;
        this.eventActionID = eventActionID;
        this.userID = userID;
        this.seat = seat;
        this.price = price;
        this.coeff = coeff;
    }

    public int getEventActionID() {
        return eventActionID;
    }

    public void setEventActionID(int eventActionID) {
        this.eventActionID = eventActionID;
    }

    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public String getSeat() {
        return seat;
    }

    public void setSeat(String seat) {
        this.seat = seat;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public double getEndPrice() {
        return price * coeff;
    }

    @Override
    public String toString() {
        return "Ticket [id=" + id + ", eventActionID=" + eventActionID + ", userID=" + userID + ", seat=" + seat + ", price=" + price
                + ", coeff=" + coeff + "]";
    }

    public boolean isLucky() {
        return lucky;
    }

    public void setLucky(boolean lucky) {
        this.lucky = lucky;
    }

}

package com.epam.spring.core.helen.yrofeeva.services.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;

import com.epam.spring.core.helen.yrofeeva.dao.AfishaDAOFactory;
import com.epam.spring.core.helen.yrofeeva.dto.Event;
import com.epam.spring.core.helen.yrofeeva.dto.EventAction;
import com.epam.spring.core.helen.yrofeeva.persistent.Auditorium;
import com.epam.spring.core.helen.yrofeeva.services.EventActionService;

public class EventActionServiceImpl implements EventActionService {
    private AfishaDAOFactory dao;

    public EventActionServiceImpl() {
    }

    @Autowired
    public EventActionServiceImpl(AfishaDAOFactory dao) {
        this.dao = dao;
    }

    //TODO: looks like it should work with multy auditorium, but you have only one. That's strange :)
    /**
     * return true if auditorium assigned yet to date-time
     * @param auditorium auditorium object
     * @param date date time to check
     * @return true or false
     */
    private boolean isAudutoriumAssigned(Auditorium auditorium, Date date) {
        Collection<EventAction> actions = getEventActions(auditorium);
        for (EventAction act : actions) {
            if(date.equals(act.getDateTimeStart())){
                return true;
            }
        }

        return false;
    }

    /**
     * this method is [equal]
     * assignAuditorium(Event event, Auditorium auditorium, Date date)
     */
    @Override
    public EventAction addEventAction(Event event, Auditorium auditorium, Date date) {
        EventAction action = null;
        if (!isAudutoriumAssigned(auditorium, date)) {
            action = new EventAction(dao.getAfishaDAOEventAction().getMaxId() + 1, event.getId(), auditorium.getId(), date);
            dao.getAfishaDAOEventAction().add(action);
        }
        return action;
    }

    @Override
    public void removeEventAction(EventAction eventAction) {
        dao.getAfishaDAOEventAction().remove(eventAction);
    }

    @Override
    public Collection<EventAction> getEventActions(Date start, Date end) {
        Collection<EventAction> coll = dao.getAfishaDAOEventAction().getAll();
        Collection<EventAction> res = new ArrayList<>();
        for (EventAction act : coll) {
            if (act.getDateTimeStart().after(start) && act.getDateTimeStart().before(end)) {
                res.add(act);
            }
        }
        return res;
    }

    @Override
    public Collection<EventAction> getEventActions(Event event) {
        //TODO: save my eyes.. 'coll'.. I didn't get what is it some first seconds o_O
        Collection<EventAction> coll = dao.getAfishaDAOEventAction().getAll();
        Collection<EventAction> res = new ArrayList<>();
        for (EventAction act : coll) {
            if (act.getEventID() == event.getId()) {
                res.add(act);
            }
        }
        return res;
    }

    @Override
    public Collection<EventAction> getEventActions(Auditorium auditorium) {
        Collection<EventAction> coll = dao.getAfishaDAOEventAction().getAll();
        Collection<EventAction> res = new ArrayList<>();
        for (EventAction act : coll) {
            if (act.getAuditoriumID() == auditorium.getId()) {
                res.add(act);
            }
        }
        return res;

    }

    @Override
    public Collection<EventAction> getEventActions(Event event, Date date) {
        Collection<EventAction> coll = dao.getAfishaDAOEventAction().getAll();
        Collection<EventAction> res = new ArrayList<>();
        for (EventAction act : coll) {
            if (act.getEventID() == event.getId() && act.getDateTimeStart().after(date)) {
                res.add(act);
            }
        }
        return res;
    }

    @Override
    public Collection<EventAction> getEventActions(Auditorium auditorium, Date date) {
        Collection<EventAction> coll = dao.getAfishaDAOEventAction().getAll();
        Collection<EventAction> res = new ArrayList<>();
        for (EventAction act : coll) {
            if (act.getAuditoriumID() == auditorium.getId() && act.getDateTimeStart().after(date)) {
                res.add(act);
            }
        }
        return res;
    }

}

package com.epam.spring.core.helen.yrofeeva.services;

import java.util.Collection;

import com.epam.spring.core.helen.yrofeeva.dto.Event;
import com.epam.spring.core.helen.yrofeeva.dto.EventRating;

public interface EventService {
    void addEvent(Event event);
    void removeEvent(Event event);
    /** return events with some rating*/
    Collection<Event> getEventsByRating(EventRating rating);
    Event getEventByName(String name);
    Event getEventById(int eventID);
}

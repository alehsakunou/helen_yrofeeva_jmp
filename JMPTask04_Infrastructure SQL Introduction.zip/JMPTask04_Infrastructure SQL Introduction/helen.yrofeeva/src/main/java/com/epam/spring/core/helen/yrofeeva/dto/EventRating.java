package com.epam.spring.core.helen.yrofeeva.dto;
/**
 * rating of events
 */
public enum EventRating {
    HIGH, MID, LOW;
    
    public static EventRating getEventRating(int ratingCode) {
        switch (ratingCode) {
        case 30:
            return HIGH;
        case 20:
            return MID;
        case 10:
            return LOW;
        default:
            return MID;
        }
    }

    public int getEventRatingCode() {
        switch (this) {
        case LOW:
            return 10;
        case MID:
            return 20;
        case HIGH:
            return 30;
        default:
            return 20;
        }
    }
}

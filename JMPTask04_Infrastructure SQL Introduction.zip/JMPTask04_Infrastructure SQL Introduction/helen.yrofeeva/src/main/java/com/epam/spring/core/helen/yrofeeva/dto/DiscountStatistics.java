package com.epam.spring.core.helen.yrofeeva.dto;

public class DiscountStatistics extends ObjectDTO {
    private int userID;
    private int count;

    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    @Override
    public String toString() {
        return "DiscountStatistics [userID=" + userID + ", count=" + count + "]";
    }

}

package com.epam.spring.core.helen.yrofeeva.dao.dbimpl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.epam.spring.core.helen.yrofeeva.dao.AfishaDAO;
import com.epam.spring.core.helen.yrofeeva.dto.Event;
import com.epam.spring.core.helen.yrofeeva.dto.EventRating;

public class DBEventAfishaDAOImpl implements AfishaDAO<Event>{
    protected  JdbcTemplate jdbcTemplate;
    private static final String SQL_ADD = "INSERT INTO Events (ID, name, rating, price, duration) VALUES (?,?,?,?,?)"; 
    private static final String SQL_DELETE = "DELETE FROM Events WHERE ID = ?"; 
    private static final String SQL_DELETE_ALL = "DELETE FROM Events"; 
    private static final String SQL_SELECT = "SELECT ID, name, rating, price, duration FROM Events WHERE ID = ?"; 
    private static final String SQL_SELECT_ALL = "SELECT ID, name, rating, price, duration FROM Events"; 
    private static final String SQL_MAX_ID = "SELECT MAX(ID) AS maxID FROM Events"; 
    
    public DBEventAfishaDAOImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }
    
    private Event fillEntity(ResultSet rs) throws SQLException {
        Event entity = new Event();
        entity.setId(rs.getInt("ID"));
        entity.setName(rs.getString("name").trim());
        entity.setRating(EventRating.getEventRating(rs.getInt("rating")));
        entity.setPrice(rs.getDouble("price"));
        entity.setDuration(rs.getInt("duration"));
        return entity;
    }
    
    @Override
    public Event getEntity(int id) {
        Event entity = jdbcTemplate.queryForObject(SQL_SELECT, new Object[] { id }, new RowMapper<Event>() {
            public Event mapRow(ResultSet rs, int rowNum) throws SQLException {
                return fillEntity(rs);
            }
        });
        return entity;
    }

    @Override
    public Collection<Event> getAll() {
        List<Event> all = jdbcTemplate.query(SQL_SELECT_ALL, new RowMapper<Event>() {
            public Event mapRow(ResultSet rs, int rowNum) throws SQLException {
                return fillEntity(rs);
            }
        });
        return all;
    }

    @Override
    public void add(Event e) {
        jdbcTemplate.update(SQL_ADD, e.getId(), e.getName(), e.getRating().getEventRatingCode(), e.getPrice(), e.getDuration());
    }

    @Override
    public void remove(Event e) {
        jdbcTemplate.update(SQL_DELETE, e.getId());
    }

    @Override
    public int getMaxId() {
        try {
            return jdbcTemplate.queryForObject(SQL_MAX_ID, Integer.class);
        } catch (Exception e) {
            return 0;
        }
    }

    @Override
    public void removeAll() {
        jdbcTemplate.update(SQL_DELETE_ALL);
    }

    @Override
    public void update(Event e) {
        // TODO Auto-generated method stub
        
    }

}

package com.epam.spring.core.helen.yrofeeva.dto;
/**
 * class - holder Event statistics
 * @author Helen_Yrofeeva
 *
 */
public class EventStatistics extends ObjectDTO{
    private int eventID;
    private int accessByName;
    private int pricesWereQueried;
    private int ticketsWereBooked;
    
    public int getEventID() {
        return eventID;
    }
    public void setEventID(int eventID) {
        this.eventID = eventID;
    }
    
    public int getAccessByName() {
        return accessByName;
    }
    //TODO: HINT: you could have methods like "increaseAccessByName"
    public void setAccessByName(int accessByName) {
        this.accessByName = accessByName;
    }
    public int getPricesWereQueried() {
        return pricesWereQueried;
    }
    public void setPricesWereQueried(int pricesWereQueried) {
        this.pricesWereQueried = pricesWereQueried;
    }
    public int getTicketsWereBooked() {
        return ticketsWereBooked;
    }
    public void setTicketsWereBooked(int ticketsWereBooked) {
        this.ticketsWereBooked = ticketsWereBooked;
    }
    
    @Override
    public String toString() {
        return "EventStatistics [eventID=" + eventID + ", accessByName=" + accessByName + ", pricesWereQueried=" + pricesWereQueried
                + ", ticketsWereBooked=" + ticketsWereBooked + "]";
    }
    
    
}

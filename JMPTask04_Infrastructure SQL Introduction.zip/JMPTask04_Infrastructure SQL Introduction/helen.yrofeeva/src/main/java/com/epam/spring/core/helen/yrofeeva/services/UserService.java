package com.epam.spring.core.helen.yrofeeva.services;

import com.epam.spring.core.helen.yrofeeva.dto.User;

public interface UserService {
    void registerUser(User user);
    void removeUser(User user);
    User getUserByName(String name);
    User getUserById(int userID);
    User getUserByEmail(String email);
}

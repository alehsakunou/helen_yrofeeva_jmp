package com.epam.spring.core.helen.yrofeeva.dao;

import java.util.Collection;

import com.epam.spring.core.helen.yrofeeva.dto.ObjectDTO;

public interface AfishaDAO<E extends ObjectDTO> {
    E getEntity(int id);
    Collection<E> getAll();
    void add(E e);
    void remove(E e);
    int getMaxId();
    void removeAll();
    void update(E e);
}

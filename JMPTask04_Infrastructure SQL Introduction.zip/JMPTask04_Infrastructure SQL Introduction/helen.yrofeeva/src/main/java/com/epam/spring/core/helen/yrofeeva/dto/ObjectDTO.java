package com.epam.spring.core.helen.yrofeeva.dto;

public class ObjectDTO {
    protected int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
}

package com.epam.spring.core.helen.yrofeeva.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.epam.spring.core.helen.yrofeeva.discount.DiscountStrategy;
import com.epam.spring.core.helen.yrofeeva.dto.EventAction;
import com.epam.spring.core.helen.yrofeeva.dto.User;
import com.epam.spring.core.helen.yrofeeva.services.DiscountService;

/**
 * count max discount = min coeff
 */
public class DiscountServiceImpl implements DiscountService {
    private List<DiscountStrategy> list;

    public DiscountServiceImpl() {
        
    }
    
    @Autowired
    public DiscountServiceImpl(List<DiscountStrategy> list) {
        this.list = list;
    }

    //TODO: why do you provide minimal discount? it looks not right (in real world).
    @Override
    public double getDiscount(EventAction action, User user) {
        double min = 1;
        for (DiscountStrategy st : list) {
            double val = st.getDiscountCoeff(action, user);
            if (val < min) {
                min = val;
            }
        }
        return min;
    }

}

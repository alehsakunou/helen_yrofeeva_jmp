package com.epam.spring.core.helen.yrofeeva.utils;

import java.text.DateFormat;
import java.text.ParseException;
import java.util.Date;
import java.util.Locale;

public class DateUtil {
    private DateFormat dateFormat;

    public DateUtil() {
        dateFormat = DateFormat.getDateTimeInstance();
    }

    public DateUtil(int formatDate, int formatTime, Locale locale) {
        dateFormat = DateFormat.getDateTimeInstance(formatDate, formatTime, locale);
    }

    public String getString(Date date) {
        return dateFormat.format(date);
    }

    public Date getDate(String date){
        try {
            Date res = dateFormat.parse(date);
            return res;
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }
}

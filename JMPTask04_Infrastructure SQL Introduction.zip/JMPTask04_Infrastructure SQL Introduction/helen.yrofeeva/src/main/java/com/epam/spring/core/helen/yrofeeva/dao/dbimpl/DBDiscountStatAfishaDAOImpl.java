package com.epam.spring.core.helen.yrofeeva.dao.dbimpl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.epam.spring.core.helen.yrofeeva.dao.AfishaDAO;
import com.epam.spring.core.helen.yrofeeva.dto.DiscountStatistics;

public class DBDiscountStatAfishaDAOImpl implements AfishaDAO<DiscountStatistics>{
    protected  JdbcTemplate jdbcTemplate;
    private static final String SQL_ADD = "INSERT INTO DiscountStatistics (ID, userID, count_) VALUES (?,?,?)"; 
    private static final String SQL_DELETE = "DELETE FROM DiscountStatistics WHERE ID = ?"; 
    private static final String SQL_DELETE_ALL = "DELETE FROM DiscountStatistics"; 
    private static final String SQL_SELECT = "SELECT ID, userID, count_ FROM DiscountStatistics WHERE ID = ?"; 
    private static final String SQL_SELECT_ALL = "SELECT ID, userID, count_ FROM DiscountStatistics"; 
    private static final String SQL_MAX_ID = "SELECT MAX(ID) AS maxID FROM DiscountStatistics"; 
    private static final String SQL_UPDATE = "UPDATE DiscountStatistics SET userID= ?, count_= ? WHERE ID = ?"; 
    
    public DBDiscountStatAfishaDAOImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }
    
    private DiscountStatistics fillEntity(ResultSet rs) throws SQLException {
        DiscountStatistics entity = new DiscountStatistics();
        entity.setId(rs.getInt("ID"));
        entity.setUserID(rs.getInt("userID"));
        entity.setCount(rs.getInt("count_"));
        return entity;
    }
    
    @Override
    public DiscountStatistics getEntity(int id) {
        DiscountStatistics entity = jdbcTemplate.queryForObject(SQL_SELECT, new Object[] { id }, new RowMapper<DiscountStatistics>() {
            public DiscountStatistics mapRow(ResultSet rs, int rowNum) throws SQLException {
                return fillEntity(rs);
            }
        });
        return entity;
    }

    @Override
    public Collection<DiscountStatistics> getAll() {
        List<DiscountStatistics> all = jdbcTemplate.query(SQL_SELECT_ALL, new RowMapper<DiscountStatistics>() {
            public DiscountStatistics mapRow(ResultSet rs, int rowNum) throws SQLException {
                return fillEntity(rs);
            }
        });
        return all;
    }

    @Override
    public void add(DiscountStatistics e) {
        jdbcTemplate.update(SQL_ADD, e.getId(), e.getUserID(), e.getCount());
    }

    @Override
    public void remove(DiscountStatistics e) {
        jdbcTemplate.update(SQL_DELETE, e.getId());
    }

    @Override
    public int getMaxId() {
        try {
            return jdbcTemplate.queryForObject(SQL_MAX_ID, Integer.class);
        } catch (Exception e) {
            return 0;
        }
    }

    @Override
    public void removeAll() {
        jdbcTemplate.update(SQL_DELETE_ALL);
    }

    @Override
    public void update(DiscountStatistics e) {
        jdbcTemplate.update(SQL_UPDATE, e.getUserID(), e.getCount(), e.getId());
    }

}

package com.epam.spring.core.helen.yrofeeva.dto;

import java.io.Serializable;

/**
 * Event with name, base price for tickets, duration in minutes, rating (high, mid, low)
 */
public class Event extends ObjectDTO implements Serializable {
    private static final long serialVersionUID = 1L;
    private String name;
    private EventRating rating;
    private double price;
    /** duration of event in minutes */
    private int duration;

    public Event() {

    }

    public Event(int id, String name, EventRating rating, double price, int duration) {
        super();
        this.id = id;
        this.name = name;
        this.rating = rating;
        this.price = price;
        this.duration = duration;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public EventRating getRating() {
        return rating;
    }

    public void setRating(EventRating rating) {
        this.rating = rating;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    @Override
    public String toString() {
        return "Event [id=" + id + ", name=" + name + ", rating=" + rating + ", price=" + price + ", duration=" + duration + "]";
    }

}

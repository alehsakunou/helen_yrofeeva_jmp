package com.epam.spring.core.helen.yrofeeva.aspects;

import java.util.Collection;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;

import com.epam.spring.core.helen.yrofeeva.dao.AfishaDAOFactory;
import com.epam.spring.core.helen.yrofeeva.dto.DiscountStatistics;
import com.epam.spring.core.helen.yrofeeva.dto.User;

@Aspect
public class DiscountAspect {
    private AfishaDAOFactory dao;

    @Autowired
    public void setDao(AfishaDAOFactory dao) {
        this.dao = dao;
    }

    private DiscountStatistics getStatisticsByUserID(int id) {
        Collection<DiscountStatistics> c = dao.getAfishaDAODiscountStatistics().getAll();
        for (DiscountStatistics stat : c) {
            if (stat.getUserID() == id ) {
                return stat;
            }
        }
        // need to create new statistics object (there is no statistics object for user)
        DiscountStatistics stat = new DiscountStatistics();
        stat.setId(dao.getAfishaDAODiscountStatistics().getMaxId() + 1);
        stat.setUserID(id);
        dao.getAfishaDAODiscountStatistics().add(stat);
        return stat;
    }

    public int getTotalCount() {
        int sum = 0;
        Collection<DiscountStatistics> c = dao.getAfishaDAODiscountStatistics().getAll();
        for (DiscountStatistics stat : c) {
            sum += stat.getCount();
        }
        return sum;
    }

    // @Pointcut("execution(double *.getDiscountCoeff(..))")
    // private void getDiscountMethods() {
    //
    // }

    /* double getDiscount(EventAction action, User user) */
    @Around("execution(double *.getDiscount(..))")
    public Object aroundGetDiscountCoeff(ProceedingJoinPoint joinPoint) throws Throwable {
        Object[] args = joinPoint.getArgs();
        User user = (User) args[1];
        Object result = null;
        try {

            result = joinPoint.proceed(args);

            Double discount = (Double) result;
            if (discount != null && discount < 1){
                DiscountStatistics discountStatistics = getStatisticsByUserID(user.getId());
                discountStatistics.setCount(discountStatistics.getCount() + 1);
                dao.getAfishaDAODiscountStatistics().update(discountStatistics);
            }
        } catch (Throwable t) {
            // log should be here
            throw t;
        }
        return result;
    }

    // @Before("getDiscountMethods()")
    // public void beforeGetTicketPrice(JoinPoint joinPoint) {
    // // I know that this is bad approach to get particular argument, but I didn't have enough time
    // User user = (User) joinPoint.getArgs()[1];
    // discountStatistics = getStatisticsByUserID(user.getId(),"");
    // }
    //
    // @AfterReturning(pointcut = "getDiscountMethods()", returning = "retVal")
    // public void countGetTicketPrice(Object retVal) {
    // Double discount = (Double) retVal;
    // if (discountStatistics != null && discount != null && discount < 1)
    // discountStatistics.setCount(discountStatistics.getCount() + 1);
    // }
}

CREATE TABLE IF NOT EXISTS Users (
    ID int NOT NULL,
    name char(50) NOT NULL,
    email char(50),
    birthday date,
    isAdmin bit DEFAULT false NOT NULL ,
    PRIMARY KEY (ID)
);

CREATE TABLE IF NOT EXISTS Events (
    ID int NOT NULL,
    name char(50) NOT NULL,
    rating int, 
    price double,
    duration int,
    PRIMARY KEY (ID)
);

CREATE TABLE IF NOT EXISTS EventActions (
    ID int NOT NULL,
    eventID int NOT NULL,
    auditoriumID int NOT NULL,
    dateTimeStart datetime,
    PRIMARY KEY (ID)
);

ALTER TABLE EventActions
    ADD CONSTRAINT EventActions_Events 
    FOREIGN KEY (eventID)
        REFERENCES Events (ID)
        ON UPDATE CASCADE 
        ON DELETE CASCADE; 

CREATE TABLE IF NOT EXISTS Tickets (
    ID int NOT NULL,
    eventActionID int NOT NULL,
    userID int NOT NULL,
    seat char(10) NOT NULL,
    price double,
    coeff double DEFAULT 1,
    lucky bit DEFAULT false NOT NULL ,
    PRIMARY KEY (ID)
);

ALTER TABLE Tickets
    ADD CONSTRAINT Tickets_Users 
    FOREIGN KEY (userID)
        REFERENCES Users (ID)
        ON UPDATE CASCADE 
        ON DELETE CASCADE;
        
ALTER TABLE Tickets
    ADD CONSTRAINT Tickets_EventActions 
    FOREIGN KEY (eventActionID)
        REFERENCES EventActions (ID)
        ON UPDATE CASCADE 
        ON DELETE CASCADE; 

CREATE TABLE IF NOT EXISTS EventStatistics (
    ID int NOT NULL,
    eventID int NOT NULL,
    accessByName int,
    pricesWereQueried int,
    ticketsWereBooked int,
    PRIMARY KEY (ID)
);      
 
ALTER TABLE EventStatistics
    ADD CONSTRAINT EventStatistics_Events 
    FOREIGN KEY (eventID)
        REFERENCES Events (ID)
        ON UPDATE CASCADE 
        ON DELETE CASCADE; 
        
 
CREATE TABLE IF NOT EXISTS DiscountStatistics (
    ID int NOT NULL,
    userID int NOT NULL,
    count_ int,
    PRIMARY KEY (ID)
);
    
ALTER TABLE DiscountStatistics
    ADD CONSTRAINT DiscountStatistics_Users 
    FOREIGN KEY (userID)
        REFERENCES Users (ID)
        ON UPDATE CASCADE 
        ON DELETE CASCADE;

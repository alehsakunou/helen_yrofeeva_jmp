package com.datalex.matrix.reservation.remotequeueremoval.handlers;

import com.datalex.matrix.adapters.connections.MatrixConnection;
import com.datalex.matrix.handlers.base.UniversalHandler;
import com.datalex.rqrs.reservation.notification.ReservationRemoteHostQueueRemovalSvRQ;
import com.datalex.rqrs.reservation.notification.ReservationRemoteHostQueueRemovalSvRS;

/**
 * The remote host queue removal handler is designed to remove the processed PNRs from the remote host Queues
 */
public interface ReservationRemoteHostQueueRemovalHandler extends UniversalHandler
{
    /**
     * Process this request
     * @param request the queue removal request
     * @param response the queue removal response
     * @param matrixconnection the connection to the remote host
     */
    void process(ReservationRemoteHostQueueRemovalSvRQ request, ReservationRemoteHostQueueRemovalSvRS response,
            MatrixConnection matrixconnection);
}

package com.datalex.servants.reservation.changeassessment.bean;

import org.apache.commons.lang.StringUtils;

import com.datalex.cbp.rqrs.CBPSvRQBase;
import com.datalex.cbp.rqrs.CBPSvRSBase;
import com.datalex.matrix.handlers.base.BusinessHandler;
import com.datalex.matrix.rules.jxpath.JXPathRulesClient;
import com.datalex.matrix.servants.MatrixBusinessServantBase;
import com.datalex.mw.bean.BeanFactory;
import com.datalex.mw.logger.Logger;
import com.datalex.mw.persistence.DBAccess;
import com.datalex.rqrs.reporting.ReportRecord;
import com.datalex.rqrs.reservation.notification.ReservationChangeAssessmentSvRQ;
import com.datalex.rqrs.reservation.notification.ReservationChangeAssessmentSvRS;
import com.datalex.rqrs.reservation.notification.ReservationChangeAssessmentSvRSTypeChoice;
import com.datalex.rqrs.reservation.notification.ReservationChangeAssessmentSvRSTypeChoiceSequence;
import com.datalex.rqrs.reservation.notification.ReservationNotificationContainerList;
import com.datalex.rqrs.reservation.notification.Success;
import com.xerxes.xml.XMLMarshaller;

/**
 * <B>Copyright (c) 2015 Datalex PLC. All Rights Reserved.</B><BR>
 * <BR>
 * 
 * Reservation change assessment service enterprise bean class.
 * 
 * @author $Author $
 * @version $Revision: 1.0 $
 * 
 * @ejb:bean name="BREReservationChangeAssessmentSv" display-name="Matrix TDP - BREReservationChangeAssessmentSv" generate="true"
 *           type="Stateless" transaction-type="Container" view-type="both"
 * @ejb:home remote-class="com.datalex.servants.reservation.changeassessment.bean.BREReservationChangeAssessmentSvHome"
 *           local-class="com.datalex.xsf.messaging.convbase.ejbimpl.EJBLocalConvServantHome"
 * @ejb:interface remote-class="com.datalex.servants.reservation.changeassessment.bean.BREReservationChangeAssessmentSv"
 *                local-class="com.datalex.xsf.messaging.convbase.ejbimpl.EJBLocalConvServant"
 * @ejb:transaction type="Supports"
 * @ejb:env-entry name="policy" type="java.lang.String" value="BREReservationChangeAssessmentSv"
 * 
 * @weblogic:enable-call-by-reference True
 * @weblogic:pool initial-beans-in-free-pool="0" max-beans-in-free-pool="100"
 * @weblogic:clustering stateless-bean-is-clusterable="True"
 * 
 * @dlex:MatrixBusinessServant type="BREReservationChangeAssessment" description="Generates a policy with
 *                             id=BREReservationChangeAssessmentSv" extends="MatrixBusinessServantBase"
 * @dlex:bean-reference id="JXPathRulesClient" bean="BREReservationChangeAssessmentRulesClient"
 *                      policy="BREReservationChangeAssessmentSv"
 */
public class BREReservationChangeAssessmentSvBean extends MatrixBusinessServantBase
{

    /** Serial UID */
    private static final long serialVersionUID = -1773008114485458928L;
    /** The reservation change assessment adaptor rules client */
    private JXPathRulesClient m_reservationChangeAssessmentRulesClient;

    /**
     * This method initializes any properties for the servant. These will be applied accordingly
     */
    @Override
    public void init()
    {
        super.init();
        m_reservationChangeAssessmentRulesClient = (JXPathRulesClient) getReference("JXPathRulesClient");
        if (isLogging(Logger.DEBUG_EVENT))
        {
            log("Initialising the BREReservationChangeAssessmentSv service...", Logger.DEBUG_EVENT);
        }
    }

    /**
     * Process method that needs to be implemented by the individual servant classes
     * 
     * @param request The CBP Request Object to process
     * @param handler The handler that maps this request to a host request
     * @param dbAccess Class that provides methods for accessing the persistance layer.
     * 
     * @return The CBP Response Object
     */
    @Override
    protected CBPSvRSBase processRequest(CBPSvRQBase request, BusinessHandler handler, DBAccess dbAccess)
    {
        if (isLogging(Logger.DEBUG_EVENT))
        {
            log("Entered " + this.getClass().getName() + ".processRequest()", Logger.DEBUG_EVENT);
        }
        ReservationChangeAssessmentSvRQ reservationChangeAssessmentSvRQ = (ReservationChangeAssessmentSvRQ) request;
        logXML(reservationChangeAssessmentSvRQ);

        ReservationChangeAssessmentSvRS reservationChangeAssessmentSvRS = buildResponse(reservationChangeAssessmentSvRQ);
        logXML(reservationChangeAssessmentSvRS);

        if (m_reservationChangeAssessmentRulesClient != null && m_reservationChangeAssessmentRulesClient.hasRules())
        {
            m_reservationChangeAssessmentRulesClient.log("BRE Rules Fired for ReservationChangeAssessmentSv Data",
                Logger.DEBUG_EVENT);
            m_reservationChangeAssessmentRulesClient.process(new Object[] {reservationChangeAssessmentSvRQ,
                reservationChangeAssessmentSvRS}, reservationChangeAssessmentSvRQ.getClientId());
            m_reservationChangeAssessmentRulesClient.log("Result after BRE to set the ReservationChangeAssessmentSv Data: ",
                Logger.DEBUG_EVENT);
            logXML(reservationChangeAssessmentSvRS);
        }
        if (isLogging(Logger.DEBUG_EVENT))
        {
            log("Exiting " + this.getClass().getName() + ".processRequest()", Logger.DEBUG_EVENT);
        }
        return reservationChangeAssessmentSvRS;
    }

    /**
     * @Override protected CBPSvRSBase processRequest(CBPSvRQBase request, UniversalHandler handler, MatrixConnection conn, DBAccess
     *           dbAccess) {
     * 
     *           }
     * 
     *           /** A method implemented in all sub-classes which returns the root XML request class corresponding to the servant.
     *           For example, the ProductServant class that extends this class will contain a getRQClass method in it that returns a
     *           ProductSvRQ.class object.
     * 
     * @return the root XML request class for the servant.
     */

    @SuppressWarnings("rawtypes")
    @Override
    protected Class getRQClass()
    {
        // TODO Auto-generated method stub
        return ReservationChangeAssessmentSvRQ.class;
    }

    /**
     * Logs marshaled object.
     * @param object {@link Object}.
     */
    public void logXML(Object object)
    {
        logMessage(null, object);
    }

    /**
     * Logs message by concatenating passed string and marshaled object if any presents.
     * @param message {@link String}.
     * @param object {@link Object}.
     */
    public void logMessage(String message, Object object)
    {
        if (isLogging(Logger.DEBUG_EVENT))
        {
            try
            {
                StringBuilder builder = new StringBuilder();

                if (StringUtils.isNotEmpty(message))
                {
                    builder = builder.append(message + " ");
                }
                if (object != null)
                {
                    XMLMarshaller xmlMarshaller = (XMLMarshaller) BeanFactory.create("XMLMarshaller");
                    xmlMarshaller.setValidation(false);
                    StringBuffer xmlBuffer = xmlMarshaller.marshal(object);
                    xmlMarshaller.setMapper(null);
                    builder = builder.append(xmlBuffer.toString());
                }
                if (StringUtils.isNotEmpty(builder.toString()))
                {
                    log(builder.toString(), Logger.DEBUG_EVENT);
                }
            }
            catch (Exception e)
            {
                log("Unable to log information", e, Logger.PROBLEM_EVENT);
            }
        }
    }

    /**
     * Build response, transmits information from the request to response.
     * @param request {@link ReservationChangeAssessmentSvRQ}.
     * 
     * @return Reservation Change Assessment response. {@link ReservationChangeAssessmentSvRS}.
     */
    private ReservationChangeAssessmentSvRS buildResponse(ReservationChangeAssessmentSvRQ request)
    {
        ReservationChangeAssessmentSvRS response = new ReservationChangeAssessmentSvRS();
        if (request != null)
        {

            response.setClientId(request.getClientId());
            response.setEchoToken(request.getEchoToken());
            response.setMajorVersion(request.getMajorVersion());
            response.setMinorVersion(request.getMinorVersion());
            response.setReportRecord(new ReportRecord());
            if (request.getReservationNotificationContainerList() != null)
            {
                response.setReservationNotificationContainerList(request.getReservationNotificationContainerList());
            }
            else
            {
                response.setReservationNotificationContainerList(new ReservationNotificationContainerList());
            }
            if (response.getReservationChangeAssessmentSvRSTypeChoice() == null)
            {
                response.setReservationChangeAssessmentSvRSTypeChoice(new ReservationChangeAssessmentSvRSTypeChoice());
            }
            response.getReservationChangeAssessmentSvRSTypeChoice().setReservationChangeAssessmentSvRSTypeChoiceSequence(
                new ReservationChangeAssessmentSvRSTypeChoiceSequence());
            response.getReservationChangeAssessmentSvRSTypeChoice().getReservationChangeAssessmentSvRSTypeChoiceSequence()
                .setSuccess(new Success());
        }
        return response;
    }
}

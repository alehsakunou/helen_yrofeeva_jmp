package com.datalex.servants.reservation.changeassessment.bean;

import javax.ejb.EJBObject;

import com.datalex.xsf.messaging.ConvServantDispatcher;
/**
 * The J2EE-Framework required "Remote" interface for the BRE Reservation Change Assessment Service
 * @author $Author$
 */
public interface BREReservationChangeAssessmentSv extends EJBObject, ConvServantDispatcher
{
    //Intentionally blank
}
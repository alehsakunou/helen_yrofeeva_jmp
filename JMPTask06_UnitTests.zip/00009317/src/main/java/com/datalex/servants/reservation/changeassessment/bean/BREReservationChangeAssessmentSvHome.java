package com.datalex.servants.reservation.changeassessment.bean;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.EJBHome;

/**
 * The J2EE-framework required "Home" interface for the BRE Reservation Change Assessment Service
 * @author $Author$
 */
public interface BREReservationChangeAssessmentSvHome extends EJBHome
{
    /**
     * Create a new instance of the remote host queue removal bean
     * @return the remote host queue removal bean
     * @throws RemoteException if an error occurs during create
     * @throws CreateException if an error occurs during create
     */
    BREReservationChangeAssessmentSv create() throws RemoteException, CreateException;
}

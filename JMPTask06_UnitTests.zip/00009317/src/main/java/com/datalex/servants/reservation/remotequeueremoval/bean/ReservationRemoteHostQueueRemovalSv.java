package com.datalex.servants.reservation.remotequeueremoval.bean;

import javax.ejb.EJBObject;

import com.datalex.xsf.messaging.ConvServantDispatcher;
/**
 * EJB Home Component interface for ReservationRemoteHostQueueRemoval Service
 */
public interface ReservationRemoteHostQueueRemovalSv extends EJBObject, ConvServantDispatcher
{

}

package com.datalex.servants.reservation.remotequeueremoval.bean;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.EJBHome;

/**
 * EJB Component interface for ReservationRemoteHostQueueRemoval servant
 */
public interface ReservationRemoteHostQueueRemovalSvHome extends EJBHome
{
    /**
     * This method creates an instance of the ReservationRemoteHostQueueRemovalSv bean
     *
     * @return An instance of ReservationRemoteHostQueueRemovalSv
     *
     * @throws RemoteException If a remote exception occurs
     * @throws CreateException If an error occurs creating
     */
    ReservationRemoteHostQueueRemovalSv create() throws RemoteException, CreateException;
}

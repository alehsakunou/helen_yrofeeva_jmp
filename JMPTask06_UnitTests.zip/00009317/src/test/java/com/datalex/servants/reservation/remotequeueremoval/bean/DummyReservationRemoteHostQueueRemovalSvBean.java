package com.datalex.servants.reservation.remotequeueremoval.bean;

import com.datalex.cbp.rqrs.CBPSvRQBase;
import com.datalex.cbp.rqrs.CBPSvRSBase;
import com.datalex.matrix.adapters.connections.MatrixConnection;
import com.datalex.matrix.handlers.base.UniversalHandler;
import com.datalex.mw.persistence.DBAccess;

/**
 * Contains methods to aid the testing of the ReservationRemoteHostQueueRemovalSvBean
 */
public class DummyReservationRemoteHostQueueRemovalSvBean extends ReservationRemoteHostQueueRemovalSvBean
{
    /** default serialVersionUID */
    private static final long serialVersionUID = 1L;

    /**
     * method aid test code ReservationRemoteHostQueueRemovalSvBean.processRequest
     * @param req The CBP Request Object to process
     * @param handler The handler that maps this request to a host request
     * @param conn The connection to the host
     * @param dbAccess Class that provides methods for accessing the persistance layer.
     * @return The CBP Response Object
     */
    @Override
    protected CBPSvRSBase processRequest(CBPSvRQBase req, UniversalHandler handler, MatrixConnection conn, DBAccess dbAccess)
    {
        return super.processRequest(req, handler, conn, dbAccess);
    }

}

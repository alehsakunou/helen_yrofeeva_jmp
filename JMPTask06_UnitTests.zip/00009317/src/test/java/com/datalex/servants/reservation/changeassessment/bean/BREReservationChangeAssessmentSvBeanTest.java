package com.datalex.servants.reservation.changeassessment.bean;

import static junit.framework.Assert.*;
import static org.mockito.Mockito.*;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.powermock.api.support.membermodification.MemberModifier;
import org.powermock.reflect.Whitebox;

import com.datalex.cbp.rqrs.CBPSvRQBase;
import com.datalex.matrix.handlers.base.BusinessHandler;
import com.datalex.matrix.rules.jxpath.JXPathRulesClient;
import com.datalex.mw.bean.BeanFactory;
import com.datalex.mw.persistence.DBAccess;
import com.datalex.rqrs.reservation.notification.ReservationChangeAssessmentSvRQ;
import com.datalex.rqrs.reservation.notification.ReservationChangeAssessmentSvRS;
import com.datalex.tests.TestUtils;
import com.datalex.tests.bean.UnitTestHelper;

/**
 * class for test BREReservationChangeAssessmentSvBean
 */
public class BREReservationChangeAssessmentSvBeanTest
{
    /** project number allows test to work out the location for resource files and beans */
    private static final String PROJECT_NUMBER = "00009317";
    /** provide bean factory and help to get path for unit test resources */
    private UnitTestHelper m_unitHelper;

    /**
     * Sets up the UnitTestHelper
     */
    @Before
    public void setUp()
    {
        m_unitHelper = new UnitTestHelper(PROJECT_NUMBER);
    }

    /**
     * Clean up variables and bean policies
     */
    @After
    public void tearDown()
    {
        m_unitHelper.cleanupBeanFactory();
        m_unitHelper = null;
    }

    /**
     * test process service with correctData, check rules client call
     * @throws Exception thrown if any problems happen during setup
     * */
    @Test
    public void processServiceWithCorrectDataCallRulesCheck() throws Exception
    {
        final String requestFilename = "success_ReservationChangeAssessmentSvRQ.xml";
        // Arrange
        ReservationChangeAssessmentSvRQ request = getClassCannedInputDirectory(ReservationChangeAssessmentSvRQ.class,
            requestFilename);
        BREReservationChangeAssessmentSvBean breResChangeAssessmentSvBean = (BREReservationChangeAssessmentSvBean) BeanFactory
            .create("Bean", "BREReservationChangeAssessmentSv");
        // Mocking
        JXPathRulesClient mockitoJXPathRulesClient = mock(JXPathRulesClient.class);
        BusinessHandler handler = mock(BusinessHandler.class);
        DBAccess dbAccess = mock(DBAccess.class);
        MemberModifier.field(BREReservationChangeAssessmentSvBean.class, "m_reservationChangeAssessmentRulesClient").set(
            breResChangeAssessmentSvBean, mockitoJXPathRulesClient);
        when(mockitoJXPathRulesClient.hasRules()).thenReturn(Boolean.TRUE);
        // Act
        Whitebox.invokeMethod(breResChangeAssessmentSvBean, "processRequest", (CBPSvRQBase) request, handler, dbAccess);
        // Assert
        verify(mockitoJXPathRulesClient, times(1)).process(anyList().toArray(), anyString());
    }

    /**
     * test process service with correctData, check response
     * @throws Exception thrown if any problems happen during setup
     * */
    @Test
    public void processServiceWithCorrectDataBuildResoponseCheck() throws Exception
    {
        final String requestFilename = "success_ReservationChangeAssessmentSvRQ.xml";
        final String expectedResponseFilename = "success_ReservationChangeAssessmentSvRS.xml";
        final String accertMessage = "Testing process method with correct data:";
        // Arrange
        ReservationChangeAssessmentSvRQ request = getClassCannedInputDirectory(ReservationChangeAssessmentSvRQ.class,
            requestFilename);
        ReservationChangeAssessmentSvRS expectedResponse = getClassCannedOutputDirectory(ReservationChangeAssessmentSvRS.class,
            expectedResponseFilename);
        BREReservationChangeAssessmentSvBean breResChangeAssessmentSvBean = (BREReservationChangeAssessmentSvBean) BeanFactory
            .create("Bean", "BREReservationChangeAssessmentSv");
        // Mocking
        BusinessHandler handler = mock(BusinessHandler.class);
        DBAccess dbAccess = mock(DBAccess.class);
        // Act
        ReservationChangeAssessmentSvRS actualResponse = Whitebox.<ReservationChangeAssessmentSvRS> invokeMethod(
            breResChangeAssessmentSvBean, "processRequest", (CBPSvRQBase) request, handler, dbAccess);
        // Assert
        assertEquals(accertMessage, expectedResponse, actualResponse);
    }

    /**
     * test check request class
     * @throws Exception thrown if any problems happen during setup
     * */
    @SuppressWarnings("rawtypes")
    @Test
    public void returnRequestClassCheck() throws Exception
    {
        final String accertMessage = "Testing returned request class";
        final Class expectedClass = ReservationChangeAssessmentSvRQ.class;
        // Arrange
        BREReservationChangeAssessmentSvBean breResChangeAssessmentSvBean = (BREReservationChangeAssessmentSvBean) BeanFactory
            .create("Bean", "BREReservationChangeAssessmentSv");
        // Act
        Class actualClass = Whitebox.<Class> invokeMethod(breResChangeAssessmentSvBean, "getRQClass");
        // Assert
        assertEquals(accertMessage, expectedClass, actualClass);
    }

    /**
     * return data from input directory.
     * @param <T> data type.
     * @param clazz class of returned data
     * @param filename data file name
     * @return data from input directory
     */
    @SuppressWarnings("unchecked")
    private <T> T getClassCannedInputDirectory(Class<T> clazz, String filename)
    {
        String filepath = m_unitHelper.getCannedInputDirectory() + filename;
        T objectFromXML = null;
        Reader reader = null;
        BufferedReader bufReader = null;
        try
        {
            reader = new FileReader(filepath);
            bufReader = new BufferedReader(reader);
            objectFromXML = (T) TestUtils.unmarshal(clazz, bufReader, false);
        }
        catch (FileNotFoundException e)
        {
            throw new RuntimeException("File not exists", e);
        }
        finally
        {
            if (bufReader != null)
            {
                try
                {
                    bufReader.close();
                }
                catch (IOException e)
                {
                    // needn't do anything
                }
            }
            if (reader != null)
            {
                try
                {
                    reader.close();
                }
                catch (IOException e)
                {
                    // needn't do anything
                }
            }
        }
        return objectFromXML;
    }

    /**
     * return data from output directory
     * @param <T> data type
     * @param clazz class of returned data
     * @param filename data file name
     * @return data from output directory
     */
    @SuppressWarnings("unchecked")
    private <T> T getClassCannedOutputDirectory(Class<T> clazz, String filename)
    {
        String filepath = m_unitHelper.getCannedOutputDirectory() + filename;
        T objectFromXML = null;
        Reader reader = null;
        BufferedReader bufReader = null;
        try
        {
            reader = new FileReader(filepath);
            bufReader = new BufferedReader(reader);
            objectFromXML = (T) TestUtils.unmarshal(clazz, bufReader, false);
        }
        catch (FileNotFoundException e)
        {
            throw new RuntimeException("File not exists", e);
        }
        finally
        {
            if (bufReader != null)
            {
                try
                {
                    bufReader.close();
                }
                catch (IOException e)
                {
                    // needn't do anything
                }
            }
            if (reader != null)
            {
                try
                {
                    reader.close();
                }
                catch (IOException e)
                {
                    // needn't do anything
                }
            }
        }
        return objectFromXML;
    }
}

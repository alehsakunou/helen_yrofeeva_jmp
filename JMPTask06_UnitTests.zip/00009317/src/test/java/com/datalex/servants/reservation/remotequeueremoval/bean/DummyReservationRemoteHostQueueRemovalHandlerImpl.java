package com.datalex.servants.reservation.remotequeueremoval.bean;

import java.util.Properties;

import com.datalex.exception.codes.M3_ContextCodes;
import com.datalex.exception.codes.M3_MajorCodes;
import com.datalex.exception.codes.M3_ReservationMinorCodes;
import com.datalex.matrix.adapters.connections.MatrixConnection;
import com.datalex.matrix.reservation.remotequeueremoval.handlers.ReservationRemoteHostQueueRemovalHandler;
import com.datalex.mw.bean.BeanPropertyInfo;
import com.datalex.mw.exception.AnyException;
import com.datalex.rqrs.reservation.notification.ReservationRemoteHostQueueRemovalSvRQ;
import com.datalex.rqrs.reservation.notification.ReservationRemoteHostQueueRemovalSvRS;
import com.datalex.rqrs.reservation.notification.Success;
import com.datalex.rqrs.reservation.notification.ReservationRemoteHostQueueRemovalSvRSSequence;

/**
 * Dummy implementation ReservationRemoteHostQueueRemovalHandler
 * Contains methods to aid the testing of the ReservationRemoteHostQueueRemovalSvBean
 */
public class DummyReservationRemoteHostQueueRemovalHandlerImpl implements ReservationRemoteHostQueueRemovalHandler
{
    /** default serialVersionUID */
    private static final long serialVersionUID = 1L;
    /** field mark necessity to throwing any exception */
    private boolean m_throwAnyException;

    /**
     * 
     */
    @Override
    public void destroy()
    {
    }

    /**
     * @param arg0 Properties object
     * @return null
     */
    @Override
    public BeanPropertyInfo[] getPropertyInfo(Properties arg0)
    {
        return null;
    }

    /**
     * @param arg0 Properties object
     */
    @Override
    public void init(Properties arg0)
    {
    }

    /**
     * mimicking of the handling response
     * @param request the queue removal request
     * @param response the queue removal response
     * @param matrixconnection the connection to the remote host
     */
    @Override
    public void process(ReservationRemoteHostQueueRemovalSvRQ request, ReservationRemoteHostQueueRemovalSvRS response,
            MatrixConnection matrixconnection)
    {
        if (m_throwAnyException)
        {
            AnyException e = new AnyException("Exception for test case");
            e.setContext(M3_ContextCodes.RESERVATION_CONTEXT_CODE);
            e.setMajor(M3_MajorCodes.RESERVATION_MAJOR_CODE);
            e.setMinor(M3_ReservationMinorCodes.REMOTE_RESERVATION_NOT_FOUND_CODE);
            throw e;
        }

        ReservationRemoteHostQueueRemovalSvRSSequence seq = response.getReservationRemoteHostQueueRemovalSvRSSequence();
        if (seq == null)
        {
            seq = new ReservationRemoteHostQueueRemovalSvRSSequence();
            response.setReservationRemoteHostQueueRemovalSvRSSequence(seq);
        }
        Success success = seq.getSuccess();
        if (success == null)
        {
            success = new Success();
            response.getReservationRemoteHostQueueRemovalSvRSSequence().setSuccess(success);
        }
    }

    /**
     * 
     * @return m_throwAnyException
     */
    public boolean isThrowAnyException()
    {
        return m_throwAnyException;
    }

    /**
     * 
     * @param throwAnyException m_throwAnyException
     */
    public void setThrowAnyException(boolean throwAnyException)
    {
        this.m_throwAnyException = throwAnyException;
    }

}

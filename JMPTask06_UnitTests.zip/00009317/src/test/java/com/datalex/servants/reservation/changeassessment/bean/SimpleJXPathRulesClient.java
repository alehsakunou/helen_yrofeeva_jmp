package com.datalex.servants.reservation.changeassessment.bean;

import com.datalex.matrix.rules.jxpath.JXPathRulesClient;

/**
 * Contains methods to aid the testing of the BREReservationChangeAssessmentSvBean
 */
public class SimpleJXPathRulesClient extends JXPathRulesClient
{

    /** serial version UID*/
    private static final long serialVersionUID = 18934757745L;

    /**
     * Destroys this bean.
     */
    @Override
    public void destroy()
    {
    }

    /**
     * Indicates whether this rules client has any rules to process.
     *
     * @return default value
     */
    @Override
    public boolean hasRules()
    {
        return false;
    }

    /**
     * Intializes this bean.
     */
    @Override
    public void init()
    {
        
    }

}

package com.datalex.servants.reservation.remotequeueremoval.bean;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.datalex.matrix.handlers.base.UniversalHandler;
import com.datalex.mw.bean.BeanFactory;
import com.datalex.rqrs.reservation.notification.ReservationRemoteHostQueueRemovalSvRQ;
import com.datalex.rqrs.reservation.notification.ReservationRemoteHostQueueRemovalSvRS;
import com.datalex.tests.TestUtils;
import com.datalex.tests.bean.UnitTestHelper;

/**
 * class for test ReservationRemoteHostQueueRemovalSvBean
 */
public class ReservationRemoteHostQueueRemovalSvBeanTest
{
    /** project number allows test to work out the location for resource files and beans */
    private static final String PROJECT_NUMBER = "00009317";
    /** provide bean factory and help to get path for unit test resources  */
    private UnitTestHelper m_unitTestHelper;

    /**
     * Sets up the UnitTestHelper and IgnorableFields, if any
     * @throws Exception thrown if any problems happen during setup
     */
    @Before
    public void setUp() throws Exception
    {
        //Set up the reference file locations
        m_unitTestHelper = new UnitTestHelper(PROJECT_NUMBER);
    }

    /**
     * Clean up variables and bean policies set during the test
     */
    @After
    public void tearDown()
    {
        //Clean up the bean factory
        m_unitTestHelper.cleanupBeanFactory();
        m_unitTestHelper = null;
    }

    /**
     * execute service bean unit test [check expected response]
     * @param inputFileName request data file name
     * @param outputFileName expected response data file name
     * @param handler dummy ReservationRemoteHostQueueRemovalHandler
     */
    private void testProcessRequest(final String inputFileName, final String outputFileName, UniversalHandler handler)
    {
        try
        {
            //get request from sample input file                    
            final ReservationRemoteHostQueueRemovalSvRQ hqrSvRQ = (ReservationRemoteHostQueueRemovalSvRQ) TestUtils.getXMLObject(
                    inputFileName, ReservationRemoteHostQueueRemovalSvRQ.class, false);

            // get dummy bean from BeanFactory
            ReservationRemoteHostQueueRemovalSvBean bean =
                    (ReservationRemoteHostQueueRemovalSvBean) BeanFactory.create("TestBean", "ReservationRemoteHostQueueRemovalSv");

            //pass request to servant and get response
            final ReservationRemoteHostQueueRemovalSvRS hqrSvRS =
                    (ReservationRemoteHostQueueRemovalSvRS) bean.processRequest(hqrSvRQ, handler, null, null);

            //get expected response             
            final ReservationRemoteHostQueueRemovalSvRS expectedHQRSvRS =
                    (ReservationRemoteHostQueueRemovalSvRS) TestUtils.getXMLObject(
                            outputFileName, ReservationRemoteHostQueueRemovalSvRS.class, false);

            final String hqrSvRSString = TestUtils.getXML(hqrSvRS, true, false);
            final String expectedHQRSvRSString = TestUtils.getXML(expectedHQRSvRS, true, false);

            //compare expected response to actual response
            assertEquals("Unexpected ReservationRemoteHostQueueRemovalSvRS response found", expectedHQRSvRSString, hqrSvRSString);

            //assertTrue("implemented", true);
        } 
        catch (Exception e)
        {
            fail(e.toString());
        }
    }

    /**
     * null handler response
     */
    @Test
    public void testProcessRequestNullHandler()
    {
        final String inputFileName = m_unitTestHelper.getCannedInputDirectory() + "ReservationRemoteHostQueueRemovalSvRQ.xml";
        final String outputFileName =
                m_unitTestHelper.getCannedOutputDirectory() + "ReservationRemoteHostQueueRemovalSvRS_NullHandler.xml";
        testProcessRequest(inputFileName, outputFileName, null);
    }

    /**
     * success response
     */
    @Test
    public void testProcessRequestHandler()
    {
        final String inputFileName = m_unitTestHelper.getCannedInputDirectory() + "ReservationRemoteHostQueueRemovalSvRQ.xml";
        final String outputFileName =
                m_unitTestHelper.getCannedOutputDirectory() + "ReservationRemoteHostQueueRemovalSvRS_success.xml";

        DummyReservationRemoteHostQueueRemovalHandlerImpl handler =
                (DummyReservationRemoteHostQueueRemovalHandlerImpl) BeanFactory.create("DummyRemoteHost-Handler",
                        "ReservationRemoteHostQueueRemovalSv");

        testProcessRequest(inputFileName, outputFileName, handler);
    }

    /**
     *  handler throws any exception
     */
    @Test
    public void testProcessRequestHandlerAnyEx()
    {
        final String inputFileName = m_unitTestHelper.getCannedInputDirectory() + "ReservationRemoteHostQueueRemovalSvRQ.xml";
        final String outputFileName =
                m_unitTestHelper.getCannedOutputDirectory() + "ReservationRemoteHostQueueRemovalSvRS_handlerAnyEx.xml";

        DummyReservationRemoteHostQueueRemovalHandlerImpl handler =
                (DummyReservationRemoteHostQueueRemovalHandlerImpl) BeanFactory.create("DummyRemoteHost-Handler",
                        "ReservationRemoteHostQueueRemovalSv");
        handler.setThrowAnyException(true);
        testProcessRequest(inputFileName, outputFileName, handler);
    }

}

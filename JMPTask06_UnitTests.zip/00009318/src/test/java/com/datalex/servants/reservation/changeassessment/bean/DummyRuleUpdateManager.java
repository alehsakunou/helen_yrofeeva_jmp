package com.datalex.servants.reservation.changeassessment.bean;

import java.util.HashMap;
import java.util.Map;

import com.datalex.matrix.rules.Rule;
import com.datalex.matrix.rules.RuleUpdateManager;
/**
 * Contains methods to aid the testing of the ReservationChangeAssessmentSvBean
 */
public class DummyRuleUpdateManager extends RuleUpdateManager
{
    /**
     * seria lVersion UID
     */
    private static final long serialVersionUID = 2105886864744315967L;

    /**
     * Initializes the rule update manager.
     */
    @Override
    public void init()
    {
    }

    /**
     * Loads the deployed rules for the given service name.
     * 
     * @param serviceName the service name identifying the rules
     * @return the deployed rules
     * @throws Exception if an error occurs loading the rules
     */
    @Override
    protected Rule[] loadRules(String serviceName) throws Exception
    {
        // TODO Auto-generated method stub
        return new Rule[0];
    }

    /**
     * Loads the latest deployment times.
     * 
     * @return a mapping of service names to the latest deployment time for that service
     */
    @SuppressWarnings("rawtypes")
    @Override
    protected Map loadDeploymentTimeStamps()
    {
        // TODO Auto-generated method stub
        return new HashMap();
    }
 
}

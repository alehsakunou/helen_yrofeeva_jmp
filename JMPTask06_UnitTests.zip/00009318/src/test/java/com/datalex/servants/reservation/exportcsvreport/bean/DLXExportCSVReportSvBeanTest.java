package com.datalex.servants.reservation.exportcsvreport.bean;

import static junit.framework.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.doCallRealMethod;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.powermock.reflect.Whitebox;

import com.datalex.cbp.rqrs.CBPSvRQBase;
import com.datalex.exception.codes.M3_AirMinorCodes;
import com.datalex.exception.codes.M3_ContextCodes;
import com.datalex.exception.codes.M3_MajorCodes;
import com.datalex.matrix.servants.resolution.adaptor.AdaptorApplication;
import com.datalex.mw.bean.BeanFactory;
import com.datalex.mw.exception.AnyException;
import com.datalex.mw.persistence.DBAccess;
import com.datalex.rqrs.base.RequestResponse;
import com.datalex.rqrs.reservation.notification.DLX_ExportCSVReportSvRQ;
import com.datalex.rqrs.reservation.notification.DLX_ExportCSVReportSvRS;
import com.datalex.tests.TestUtils;
import com.datalex.tests.bean.UnitTestHelper;

/**
 * class for test DLXExportCSVReportSvBean
 */
public class DLXExportCSVReportSvBeanTest
{
    /** project number allows test to work out the location for resource files and beans */
    private static final String PROJECT_NUMBER = "00009318";
    /** provide bean factory and help to get path for unit test resources */
    private UnitTestHelper m_unitHelper;

    /**
     * Sets up the UnitTestHelper
     */
    @Before
    public void setUp()
    {
        m_unitHelper = new UnitTestHelper(PROJECT_NUMBER);
    }

    /**
     * Clean up variables and bean policies
     */
    @After
    public void tearDown()
    {
        m_unitHelper.cleanupBeanFactory();
        m_unitHelper = null;
    }

    /**
     * test check request class
     * @throws Exception thrown if any problems happen during setup
     * */
    @SuppressWarnings("rawtypes")
    @Test
    public void returnRequestClassCheck() throws Exception
    {
        final String accertMessage = "Testing returned request class";
        final Class expectedClass = DLX_ExportCSVReportSvRQ.class;
        // Arrange
        DLXExportCSVReportSvBean dlxExportCSVReportSvBean = (DLXExportCSVReportSvBean) BeanFactory.create("Bean",
            "DLXExportCSVReportSv");
        // Act
        Class actualClass = Whitebox.<Class> invokeMethod(dlxExportCSVReportSvBean, "getRQClass");
        // Assert
        assertEquals(accertMessage, expectedClass, actualClass);
    }

    /**
     * test process service with correctData, check call sendReceive() method
     * @throws Exception thrown if any problems happen during setup
     * */
    @Test
    public void processServiceCallSendReceiveCheck() throws Exception
    {
        final String requestFilename = "success_DLX_ExportCSVReportSvRQ.xml";
        final int resolvedAdaptorsSize = 0;
        // Arrange
        DLX_ExportCSVReportSvRQ request = getClassCannedInputDirectory(DLX_ExportCSVReportSvRQ.class, requestFilename);
        // Mocking
        DummyDLXExportCSVReportSvBean mockDLXExportCSVReportSvBean = mock(DummyDLXExportCSVReportSvBean.class);
        AdaptorApplication[] resolvedAdaptors = getAdaptorApplicationArray(resolvedAdaptorsSize);
        DBAccess dbAccess = mock(DBAccess.class);
        doCallRealMethod().when(mockDLXExportCSVReportSvBean).processRequest(request, resolvedAdaptors, dbAccess);
        when(
            mockDLXExportCSVReportSvBean.sendReceive(any(CBPSvRQBase.class), any(CBPSvRQBase[].class),
                any(AdaptorApplication[].class), any(AnyException[].class))).thenReturn(
            new DLX_ExportCSVReportSvRS[] {new DLX_ExportCSVReportSvRS()});
        // Act
        Whitebox.invokeMethod(mockDLXExportCSVReportSvBean, "processRequest", (CBPSvRQBase) request, resolvedAdaptors, dbAccess);
        // Assert
        verify(mockDLXExportCSVReportSvBean, times(1)).sendReceive(eq(request), any(CBPSvRQBase[].class), eq(resolvedAdaptors),
            any(AnyException[].class));
    }

    /**
     * test process service with correctData, but responses not return, check throw AnyException
     * @throws Exception thrown if any problems happen during setup
     * */
    @Test(expected = AnyException.class)
    public void processServiceWithoutResponsesAnyExceptionExpected() throws Exception
    {
        final String requestFilename = "success_DLX_ExportCSVReportSvRQ.xml";
        final int resolvedAdaptorsSize = 2;
        // Arrange
        DLX_ExportCSVReportSvRQ request = getClassCannedInputDirectory(DLX_ExportCSVReportSvRQ.class, requestFilename);
        // Mocking
        DummyDLXExportCSVReportSvBean mockDLXExportCSVReportSvBean = mock(DummyDLXExportCSVReportSvBean.class);
        AdaptorApplication[] resolvedAdaptors = new AdaptorApplication[resolvedAdaptorsSize];
        DBAccess dbAccess = mock(DBAccess.class);
        doCallRealMethod().when(mockDLXExportCSVReportSvBean).processRequest(request, resolvedAdaptors, dbAccess);
        when(
            mockDLXExportCSVReportSvBean.sendReceive(eq(request), any(CBPSvRQBase[].class), eq(resolvedAdaptors),
                any(AnyException[].class))).thenReturn(new DLX_ExportCSVReportSvRS[] {});
        // Act
        Whitebox.invokeMethod(mockDLXExportCSVReportSvBean, "processRequest", (CBPSvRQBase) request, resolvedAdaptors, dbAccess);
    }

    /**
     * test addAdapterWarnings() method with more that one adapter
     * @throws Exception thrown if any problems happen during setup
     * */
    @Test
    public void processAddAdapterWarningsCheckAddedWarnings() throws Exception
    {
        final String expectedResponseFilename = "adapterWarnings_DLX_ExportCSVReportSvRS.xml";
        final int resolvedAdaptorsSize = 4;
        final int adaptorApplicationsSize = 1;
        final String accertMessage = "Testing addAdapterWarnings() method with more that one adapter:";
        // Arrange
        DLX_ExportCSVReportSvRS expectedResponse = getClassCannedOutputDirectory(DLX_ExportCSVReportSvRS.class,
            expectedResponseFilename);
        DLX_ExportCSVReportSvRS actualResponse = new DLX_ExportCSVReportSvRS();
        DLXExportCSVReportSvBean dlxExportCSVReportSvBean = (DLXExportCSVReportSvBean) BeanFactory.create("Bean",
            "DLXExportCSVReportSv");
        AdaptorApplication[] resolvedAdaptors = getAdaptorApplicationArray(resolvedAdaptorsSize);
        AdaptorApplication[] adaptorApplications = getAdaptorApplicationArray(adaptorApplicationsSize);
        // Act
        Whitebox
            .invokeMethod(dlxExportCSVReportSvBean, "addAdapterWarnings", actualResponse, resolvedAdaptors, adaptorApplications);
        // Assert
        assertEquals(accertMessage, expectedResponse, actualResponse);
    }

    /**
     * test addErrors() method
     * @throws Exception thrown if any problems happen during setup
     * */
    @Test
    public void processAddErrorsCheckAddedErrors() throws Exception
    {
        final String expectedResponseFilename = "errors_DLX_ExportCSVReportSvRS.xml";
        final int errorsArraySize = 3;
        final int secondElementIndex = 1;
        final int thirdElementIndex = 2;
        final String accertMessage = "Testing addErrors() method:";
        // Arrange
        DLX_ExportCSVReportSvRS expectedResponse = getClassCannedOutputDirectory(DLX_ExportCSVReportSvRS.class,
            expectedResponseFilename);

        DLX_ExportCSVReportSvRS actualResponse = new DLX_ExportCSVReportSvRS();
        DLXExportCSVReportSvBean dlxExportCSVReportSvBean = (DLXExportCSVReportSvBean) BeanFactory.create("Bean",
            "DLXExportCSVReportSv");
        AnyException[] anyExceptions = new AnyException[errorsArraySize];
        // first element is null
        anyExceptions[secondElementIndex] = new AnyException("Second Exception", M3_ContextCodes.ACE_CONTEXT_CODE,
            M3_MajorCodes.NO_INFO_FOR_CUSTOMER, M3_AirMinorCodes.NO_SPECIALCODE_FIRST_NAME_ERROR);
        anyExceptions[thirdElementIndex] = new AnyException("Third Exception", M3_ContextCodes.BRE_CONTEXT_CODE,
            M3_MajorCodes.NO_RESPONSE_FROM_PMS, M3_AirMinorCodes.RESTART_PIN_PAD_OR_PROCESS_AS_SIGNATURE_DEBIT);
        // Act
        Whitebox.invokeMethod(dlxExportCSVReportSvBean, "addErrors", actualResponse, anyExceptions);

        // Assert
        assertEquals(accertMessage, expectedResponse, actualResponse);
    }

    /**
     * test addWarning() method
     * @throws Exception thrown if any problems happen during setup
     * */
    @Test
    public void processAddWarningCheckAddedWarning() throws Exception
    {
        final String requestFilename = "success_DLX_ExportCSVReportSvRQ.xml";
        final String expectedResponseFilename = "warnings_DLX_ExportCSVReportSvRS.xml";
        final String accertMessage = "Testing addWarnings() method:";

        // Arrange
        DLX_ExportCSVReportSvRQ request = getClassCannedInputDirectory(DLX_ExportCSVReportSvRQ.class, requestFilename);
        DLX_ExportCSVReportSvRS expectedResponse = getClassCannedOutputDirectory(DLX_ExportCSVReportSvRS.class,
            expectedResponseFilename);
        DLXExportCSVReportSvBean dlxExportCSVReportSvBean = (DLXExportCSVReportSvBean) BeanFactory.create("Bean",
            "DLXExportCSVReportSv");
        AnyException anyException = new AnyException("Added Exception", M3_ContextCodes.ACE_CONTEXT_CODE,
            M3_MajorCodes.NO_INFO_FOR_CUSTOMER, M3_AirMinorCodes.NO_SPECIALCODE_FIRST_NAME_ERROR);

        // Act
        DLX_ExportCSVReportSvRS actualResponse = Whitebox.<DLX_ExportCSVReportSvRS> invokeMethod(dlxExportCSVReportSvBean,
            "addWarning", request, anyException);
        // Assert
        assertEquals(accertMessage, expectedResponse, actualResponse);
    }

    /**
     * generate AdaptorApplication array for tests
     * @param size array length
     * @return generated AdaptorApplication array
     * */
    private AdaptorApplication[] getAdaptorApplicationArray(int size)
    {
        AdaptorApplication[] adaptorApplications = new AdaptorApplication[size];
        final String defaultName = "Adaptor";
        for (int i = 0; i < adaptorApplications.length; i++)
        {
            adaptorApplications[i] = new AdaptorApplication();
            adaptorApplications[i].setName(String.format("%s_%d", defaultName, i));
        }
        return adaptorApplications;
    }

    /**
     * return data from input directory.
     * @param <T> data type.
     * @param clazz class of returned data
     * @param filename data file name
     * @return data from input directory
     */
    @SuppressWarnings("unchecked")
    private <T> T getClassCannedInputDirectory(Class<T> clazz, String filename)
    {
        String filepath = m_unitHelper.getCannedInputDirectory() + filename;
        T objectFromXML = null;
        Reader reader = null;
        BufferedReader bufReader = null;
        try
        {
            reader = new FileReader(filepath);
            bufReader = new BufferedReader(reader);
            objectFromXML = (T) TestUtils.unmarshal(clazz, bufReader, false);
        }
        catch (FileNotFoundException e)
        {
            throw new RuntimeException("File not exists", e);
        }
        finally
        {
            if (bufReader != null)
            {
                try
                {
                    bufReader.close();
                }
                catch (IOException e)
                {
                    // needn't do anything
                }
            }
            if (reader != null)
            {
                try
                {
                    reader.close();
                }
                catch (IOException e)
                {
                    // needn't do anything
                }
            }
        }
        return objectFromXML;
    }

    /**
     * return data from output directory
     * @param <T> data type
     * @param clazz class of returned data
     * @param filename data file name
     * @return data from output directory
     */
    @SuppressWarnings("unchecked")
    private <T> T getClassCannedOutputDirectory(Class<T> clazz, String filename)
    {
        String filepath = m_unitHelper.getCannedOutputDirectory() + filename;
        T objectFromXML = null;
        Reader reader = null;
        BufferedReader bufReader = null;
        try
        {
            reader = new FileReader(filepath);
            bufReader = new BufferedReader(reader);
            objectFromXML = (T) TestUtils.unmarshal(clazz, bufReader, false);
        }
        catch (FileNotFoundException e)
        {
            throw new RuntimeException("File not exists", e);
        }
        finally
        {
            if (bufReader != null)
            {
                try
                {
                    bufReader.close();
                }
                catch (IOException e)
                {
                    // needn't do anything
                }
            }
            if (reader != null)
            {
                try
                {
                    reader.close();
                }
                catch (IOException e)
                {
                    // needn't do anything
                }
            }
        }
        return objectFromXML;
    }

    /**
     * Contains methods to aid the testing of the DLXExportCSVReportSvBean
     */
    private class DummyDLXExportCSVReportSvBean extends DLXExportCSVReportSvBean
    {

        /**
         * serial Version UID
         */
        private static final long serialVersionUID = 2936821579527117303L;

        /**
         * A method that either calls adaptor services synchronously or asynchronously and returns the responses
         * 
         * @param request This the XML request to be sent.
         * @param adaptorRequests This is the array of requests to be populated and sent to the associated adaptors
         * @param adaptorApplications This is the adaptor configuration defined in {@link AdaptorApplication}
         * @param anyExceptions This is an array of exceptions that is populated when exceptions occur
         * @return Returns an array of {@link RequestResponse}s representing the responses returned from the called adaptor services
         */
        @Override
        protected RequestResponse[] sendReceive(CBPSvRQBase request, CBPSvRQBase[] adaptorRequests,
            AdaptorApplication[] adaptorApplications, AnyException[] anyExceptions)
        {
            return super.sendReceive(request, adaptorRequests, adaptorApplications, anyExceptions);
        }

    }
}

package com.datalex.servants.reservation.maintain.remotequeueremoval.bean;

import com.datalex.cbp.rqrs.CBPSvRQBase;
import com.datalex.cbp.rqrs.CBPSvRSBase;
import com.datalex.matrix.servants.resolution.adaptor.AdaptorApplication;
import com.datalex.mw.exception.AnyException;
import com.datalex.mw.persistence.DBAccess;
import com.datalex.rqrs.base.RequestResponse;
import com.datalex.rqrs.reservation.notification.ReservationRemoteHostQueueRemovalSvRS;
import com.datalex.rqrs.reservation.notification.ReservationRemoteHostQueueRemovalSvRSSequence;
import com.datalex.rqrs.reservation.notification.Success;
import com.datalex.xsf.messaging.ServiceException;

/**
 * Contains methods to aid the testing of the ReservationMaintainRemoteHostQueueRemovalSvBean
 */
public class DummyReservationMaintainRemoteHostQueueRemovalSvBean extends ReservationMaintainRemoteHostQueueRemovalSvBean
{
    /** default serialVersionUID */
    private static final long serialVersionUID = 1L;

    /** hide parent initialization to avoid have deal with rules client and adaptor resolutions */
    public void init()
    {
    }
    
    /**
     * method aid test code ReservationMaintainRemoteHostQueueRemovalSvBean.processRequest
     * @param request Request object in the case the {@link ReservationRemoteHostQueueRemovalSvRQ} reference
     * @param resolvedAdaptors This is the array of {@link AdaptorApplication}s or resolved set of adaptors.
     * @param dbAccess The {@link DBAccess} reference used to access a database - not used for this service.
     * 
     * @return Reservation Remote Host Queue Removal response.
     */
    @Override
    protected CBPSvRSBase processRequest(CBPSvRQBase request, AdaptorApplication[] resolvedAdaptors, DBAccess dbAccess)
    {
        ReservationRemoteHostQueueRemovalSvRS resp = null;
        try
        {
            resp = (ReservationRemoteHostQueueRemovalSvRS) super.processRequest(request, resolvedAdaptors, dbAccess);
            ReservationRemoteHostQueueRemovalSvRSSequence seq = resp.getReservationRemoteHostQueueRemovalSvRSSequence();
            if (seq == null)
            {
                seq = new ReservationRemoteHostQueueRemovalSvRSSequence();
                resp.setReservationRemoteHostQueueRemovalSvRSSequence(seq);
            }
            if (resolvedAdaptors.length > 0 && !"DummyAdaptor X".equals(resolvedAdaptors[0].getName()))
            {
                Success success = seq.getSuccess();
                if (success == null)
                {
                    success = new Success();
                    resp.getReservationRemoteHostQueueRemovalSvRSSequence().setSuccess(success);
                }
            }
            return resp;
        }
        catch (AnyException e)
        {
            resp = (ReservationRemoteHostQueueRemovalSvRS) addWarning(request, e);
            return resp;
        }
    }

    /**
     * method mimicking adapters work
     * @param request This the XML request to be sent.
     * @param adaptorRequests This is the array of requests to be populated and sent to the associated adaptors
     * @param adaptorApplications This is the adaptor configuration defined in {@link AdaptorApplication}
     * @param anyExceptions This is an array of exceptions that is populated when exceptions occur
     * @return Returns an array of {@link RequestResponse}s representing the responses returned from the called adaptor services
     */
    @Override
    protected RequestResponse[] sendReceive(CBPSvRQBase request, CBPSvRQBase[] adaptorRequests,
            AdaptorApplication[] adaptorApplications, AnyException[] anyExceptions)
    {
        RequestResponse[] resp = new ReservationRemoteHostQueueRemovalSvRS[adaptorApplications.length];
        for (int i = 0; i < adaptorApplications.length; i++)
        {
            resp[i] = new ReservationRemoteHostQueueRemovalSvRS();
        }
        if (adaptorApplications.length > 0 && "DummyAdaptor X".equals(adaptorApplications[0].getName()))
        {
            AnyException e = new ServiceException("Dummy AnyException from Adaptor", 0, 0, 0);
            anyExceptions[0] = e;
        }
        return resp;
    }

}

package com.datalex.servants.reservation.maintain.remotequeueremoval.bean;

import javax.ejb.EJBObject;

import com.datalex.xsf.messaging.ConvServantDispatcher;
/**
 * The J2EE-Framework required "Remote" interface for the Remote Host Queue Removal Service
 * @author $Author$
 */
public interface ReservationMaintainRemoteHostQueueRemovalSv extends EJBObject, ConvServantDispatcher
{
    //Intentionally blank
}

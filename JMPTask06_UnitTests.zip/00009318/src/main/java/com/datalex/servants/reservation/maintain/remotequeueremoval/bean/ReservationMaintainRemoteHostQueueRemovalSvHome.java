package com.datalex.servants.reservation.maintain.remotequeueremoval.bean;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.EJBHome;

/**
 * The J2EE-framework required "Home" interface for the Queue Removal Service
 * @author $Author$
 */
public interface ReservationMaintainRemoteHostQueueRemovalSvHome extends EJBHome
{
    /**
     * Create a new instance of the remote host queue removal bean
     * @return the remote host queue removal bean
     * @throws RemoteException if an error occurs during create
     * @throws CreateException if an error occurs during create
     */
    ReservationMaintainRemoteHostQueueRemovalSv create() throws RemoteException, CreateException;
}

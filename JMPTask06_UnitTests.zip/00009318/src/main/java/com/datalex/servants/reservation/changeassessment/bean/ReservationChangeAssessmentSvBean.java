/**
 * Copyright (C) 2015 Datalex. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Datalex
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * licence agreement you entered into with Datalex.
 *
 */
package com.datalex.servants.reservation.changeassessment.bean;

import com.datalex.cbp.rqrs.CBPSvRQBase;
import com.datalex.cbp.rqrs.CBPSvRSBase;
import com.datalex.exception.codes.M3_AirMinorCodes;
import com.datalex.exception.codes.M3_ContextCodes;
import com.datalex.exception.codes.M3_MajorCodes;
import com.datalex.matrix.servants.TDPBusinessServantBase;
import com.datalex.matrix.servants.ota.air.util.WarningUtil;
import com.datalex.matrix.servants.resolution.adaptor.AdaptorApplication;
import com.datalex.mw.exception.AnyException;
import com.datalex.mw.logger.Logger;
import com.datalex.mw.persistence.DBAccess;
import com.datalex.ota.rqrs.air.Warning;
import com.datalex.ota.rqrs.air.extensions.types.errors.Error;
import com.datalex.ota.rqrs.air.extensions.types.errors.ErrorCode;
import com.datalex.ota.rqrs.air.extensions.types.errors.TPA_Extension;
import com.datalex.rqrs.common.WarningCode;
import com.datalex.rqrs.common.types.WARNING;
import com.datalex.rqrs.reservation.notification.Errors;
import com.datalex.rqrs.reservation.notification.ReservationChangeAssessmentSvRQ;
import com.datalex.rqrs.reservation.notification.ReservationChangeAssessmentSvRS;
import com.datalex.rqrs.reservation.notification.ReservationChangeAssessmentSvRSTypeChoice;
import com.datalex.rqrs.reservation.notification.ReservationChangeAssessmentSvRSTypeChoiceSequence;
import com.datalex.rqrs.reservation.notification.Warnings;
import com.datalex.xsf.messaging.ServiceException;

/**
 * Facade Added for the Notification Scheduler. Reservation Change Assessment Service enterprise bean class.
 * @ejb:bean name="ReservationChangeAssessmentSv" display-name="ReservationChangeAssessmentSv" generate="true" type="Stateless"
 *           transaction-type="Container" view-type="remote"
 * @ejb:home remote-class="com.datalex.servants.reservation.changeassessment.bean.ReservationChangeAssessmentSvHome"
 * @ejb:interface remote-class="com.datalex.servants.reservation.changeassessment.bean.ReservationChangeAssessmentSv"
 * @ejb:transaction type="NotSupported"
 * @ejb:env-entry name="policy" type="java.lang.String" value="ReservationChangeAssessmentSv"
 * 
 * @weblogic:enable-call-by-reference True
 * @weblogic:pool initial-beans-in-free-pool="0" max-beans-in-free-pool="100"
 * @weblogic:clustering stateless-bean-is-clusterable="True"
 * 
 * @dlex:MatrixBusinessServant type="ReservationChangeAssessment"
 *                             description="Generates a policy with id=ReservationChangeAssessmentSv"
 *                             extends="TDPBusinessServantBase"
 * 
 * @dlex:bean-property name="ResponseType" value="com.datalex.rqrs.reservation.notification.ReservationChangeAssessmentSvRS"
 *                     description="This is the response type for this service"
 * @dlex:bean-property name="ServiceId" value="ReservationChangeAssessmentSv" description="This is the TDP service name"
 * 
 * @dlex:ErrorDeclaration ref="com.datalex.exception.codes.M3_ContextCodes.OTA_SERVANT_CONTEXT_CODE"
 * @dlex:ErrorDeclaration ref="com.datalex.exception.codes.M3_MajorCodes.MANAGE_SERVANT_CONTEXT"
 * @dlex:ErrorDeclaration ref="com.datalex.exception.codes.M3_AirMinorCodes.INVALID_RESPONSE_FROM_SERVANT"
 */
public class ReservationChangeAssessmentSvBean extends TDPBusinessServantBase
{

    /** Serial UID */
    private static final long serialVersionUID = -13453656342345L;
    /** The constant that defines the maximum number of adaptors that should have been resolved **/
    private static final int MAX_RESOLVED_ADAPTORS = 1;
    /** The constant that defines the default error type */
    private static final String ERROR_DEFAULT_TYPE = "1.ERR";

    /**
     * This method initializes any properties for the servant. These will be applied accordingly
     */
    public void init()
    {
        super.init();
        if (isLogging(Logger.DEBUG_EVENT))
        {
            log("Initialising the ReservationChangeAssessmentSv service...", Logger.DEBUG_EVENT);
        }
    }

    /**
     * Get the request class
     * @return the request class type
     */
    @SuppressWarnings("rawtypes")
    protected final Class getRQClass()
    {
        return ReservationChangeAssessmentSvRQ.class;
    }

    /**
     * This method should be implemented in all subclass implementations. This method should set the remote system code retrieved
     * from the adaptor configuration in the associated specific XML request.
     * 
     * @param request This is the XML request to be updated
     * @param remoteSystemCode The remote system code to be inserted
     */
    @Override
    protected void setRemoteSystemCode(CBPSvRQBase request, String remoteSystemCode)
    {
        if (request != null && remoteSystemCode != null)
        {
            if (isLogging(Logger.DEBUG_EVENT))
            {
                log("Entered setRemoteSystemCode for the ReservationChangeAssessmentSv Service...", Logger.DEBUG_EVENT);
                log("remoteSystemCode = " + remoteSystemCode, Logger.DEBUG_EVENT);
            }
        }
    }

    /**
     * Servant request contains a list of reservation information to allow PNRs to be removed from the Notification Queue. Sends
     * this request to a configured adaptor and returns response returned by this adaptor. Only one adaptor can be resolved for this
     * service.
     * 
     * @param request Request object in the case the {@link ReservationChangeAssessmentSvRQ} reference
     * @param resolvedAdaptors This is the array of {@link AdaptorApplication}s or resolved set of adaptors.
     * @param dbAccess The {@link DBAccess} reference used to access a database - not used for this service.
     * 
     * @return Reservation Change Assessment response.
     */
    @Override
    protected CBPSvRSBase processRequest(CBPSvRQBase request, AdaptorApplication[] resolvedAdaptors, DBAccess dbAccess)
    {
        AdaptorApplication[] adaptorApplications = resolvedAdaptors;
        if (resolvedAdaptors.length > MAX_RESOLVED_ADAPTORS)
        {
            adaptorApplications = new AdaptorApplication[MAX_RESOLVED_ADAPTORS];
            for (int i = 0; i < MAX_RESOLVED_ADAPTORS; i++)
            {
                adaptorApplications[i] = resolvedAdaptors[i];
            }
        }
        ReservationChangeAssessmentSvRQ reservationChangeAssessmentSvRQ = (ReservationChangeAssessmentSvRQ) request;
        AnyException[] anyExceptions = new ServiceException[adaptorApplications.length];
        ReservationChangeAssessmentSvRQ[] adaptorRequests = new ReservationChangeAssessmentSvRQ[adaptorApplications.length];
        // Send the request to adaptor and receive a response.
        ReservationChangeAssessmentSvRS[] responses = (ReservationChangeAssessmentSvRS[]) sendReceive(
            reservationChangeAssessmentSvRQ, adaptorRequests, adaptorApplications, anyExceptions);

        /* Check that the responses have a valid set of values */
        if ((responses == null) || (responses.length <= 0) || (responses[0] == null))
        {
            throw new AnyException("No responses received for the ReservationChangeAssessment service request",
                M3_ContextCodes.OTA_SERVANT_CONTEXT_CODE, M3_MajorCodes.MANAGE_SERVANT_CONTEXT,
                M3_AirMinorCodes.INVALID_RESPONSE_FROM_SERVANT);
        }

        ReservationChangeAssessmentSvRS reservationChangeAssessmentSvRS = processResponse(adaptorRequests, responses,
            adaptorApplications, anyExceptions);
        /*
         * Now deal with the case where more than one adaptor was returned -- should never happen in reality - however the user may
         * configure the system incorrectly If this is the case just add a warning for each of the other adaptors that were
         * configured
         */
        addAdapterWarnings(reservationChangeAssessmentSvRS, resolvedAdaptors, adaptorApplications);

        return reservationChangeAssessmentSvRS;
    }

    /**
     * This method deals with the case where more than one adaptor was returned -- should never happen in reality - however the user
     * may configure the system incorrectly. If this is the case just add a warning for each of the other adaptors that were
     * configured.
     * 
     * @param reservationChangeAssessmentSvRS This is the {@link ReservationChangeAssessmentSvRS} to be updated
     * @param resolvedAdaptors This is the array of {@link AdaptorApplication} resolved adaptors
     * @param adaptorApplications This is the set of adaptor configurations used when calling the host systems (this is a subset of
     *            the resolvedAdaptors - usually the first one)
     */
    private void addAdapterWarnings(ReservationChangeAssessmentSvRS reservationChangeAssessmentSvRS,
        AdaptorApplication[] resolvedAdaptors, AdaptorApplication[] adaptorApplications)
    {
        if (resolvedAdaptors.length > adaptorApplications.length)
        {
            if (isDebugEnabled())
            {
                debug("Entered addAdapterWarnings for the ReservationChangeAssessment Service...");
            }
            for (int i = adaptorApplications.length; i < resolvedAdaptors.length; i++)
            {
                WarningCode wc = reservationChangeAssessmentSvRS.createWarningCode();
                wc.setWarning(WARNING.UNMAPPED_WARNING);
                wc.setDescription("Adaptor: " + resolvedAdaptors[i].getName() + " has not been processed as only "
                    + MAX_RESOLVED_ADAPTORS + " adaptor(s) may be used for this service");
                reservationChangeAssessmentSvRS.addWarningCode(wc);
            }

        }

    }

    /**
     * This method should be overwritten in all subclass implementations to add warnings in the response when an exception occurs
     * (e.g. no adaptors found, etc.)
     * 
     * @param request - The request
     * @param appException - The Exception to be processed
     * @return CBPSvRSBase
     */
    @Override
    protected CBPSvRSBase addWarning(CBPSvRQBase request, AnyException appException)
    {
        ReservationChangeAssessmentSvRS response = new ReservationChangeAssessmentSvRS();

        response.setMajorVersion(request.getMajorVersion());
        response.setMinorVersion(request.getMinorVersion());
        response.setClientId(request.getClientId());

        if (request.getUniqueId() != null)
        {
            response.setUniqueId(request.getUniqueId());
        }

        Warnings warnings = new Warnings();
        Warning warning = WarningUtil.createWarning(appException.getContext(), appException.getMajor(), appException.getMinor(),
            appException.getMessage());
        warnings.addWarning(warning);
        response.setReservationChangeAssessmentSvRSTypeChoice(new ReservationChangeAssessmentSvRSTypeChoice());
        response.getReservationChangeAssessmentSvRSTypeChoice().setReservationChangeAssessmentSvRSTypeChoiceSequence(
            new ReservationChangeAssessmentSvRSTypeChoiceSequence());
        response.getReservationChangeAssessmentSvRSTypeChoice().getReservationChangeAssessmentSvRSTypeChoiceSequence()
            .setWarnings(warnings);

        return response;
    }

    /**
     * Process method that needs to be implemented by the individual servant classes. This method receives the original XML request
     * reference and also a list of responses that have already been received by the adaptors that have been called. This method can
     * be used to execute further specific processing (for example combining all responses into one and potentially removing any
     * duplicate entries).
     * 
     * @param adaptorRequests This is the array of {@link ReservationChangeAssessmentSvRQ} adaptor requests
     * @param responses This is the array of {@link ReservationChangeAssessmentSvRS} responses that have been received
     * @param adaptorApplications This is the array of {@link AdaptorApplication} references
     * @param anyExceptions This is an array of {@link AnyException}s used for populating the responses
     * 
     * @return Returns a newly populated {@link DLX_AirBookSvRS} response reference
     * 
     * @see com.datalex.mw.persistence.DBAccess
     */
    private ReservationChangeAssessmentSvRS processResponse(ReservationChangeAssessmentSvRQ[] adaptorRequests,
        ReservationChangeAssessmentSvRS[] responses, AdaptorApplication[] adaptorApplications, AnyException[] anyExceptions)
    {
        if (isDebugEnabled())
        {
            debug("Entered processResponse for the ReservationChangeAssessment Service...");
        }

        ReservationChangeAssessmentSvRS reservationChangeAssessmentSvRS = responses[0];
        addErrors(reservationChangeAssessmentSvRS, anyExceptions);

        if (isDebugEnabled())
        {
            debug("Exiting processResponse for the ReservationChangeAssessment Service...");
        }
        return reservationChangeAssessmentSvRS;
    }

    /**
     * Added errors at the response
     * 
     * @param reservationChangeAssessmentSvRS This is the response of {@link ReservationChangeAssessmentSvRS}
     * @param anyExceptions This is an array of {@link AnyException}s used for populating the responses
     */
    private void addErrors(ReservationChangeAssessmentSvRS reservationChangeAssessmentSvRS, AnyException[] anyExceptions)
    {

        if (anyExceptions != null && anyExceptions.length > 0)
        {
            boolean isNotNullExceptions = false;
            for (int i = 0; i < anyExceptions.length; i++)
            {
                if (anyExceptions[i] != null)
                {
                    isNotNullExceptions = true;
                    break;
                }
            }
            if (isNotNullExceptions)
            {
                if (reservationChangeAssessmentSvRS.getReservationChangeAssessmentSvRSTypeChoice() == null)
                {
                    reservationChangeAssessmentSvRS
                        .setReservationChangeAssessmentSvRSTypeChoice(new ReservationChangeAssessmentSvRSTypeChoice());
                }
                ReservationChangeAssessmentSvRSTypeChoice reservationChangeAssessmentSvRSChoice = reservationChangeAssessmentSvRS
                    .getReservationChangeAssessmentSvRSTypeChoice();
                if (reservationChangeAssessmentSvRSChoice.getErrors() == null)
                {
                    reservationChangeAssessmentSvRSChoice.setErrors(new Errors());
                }
                if (reservationChangeAssessmentSvRSChoice.getErrors().getTPA_Extension() == null)
                {
                    reservationChangeAssessmentSvRSChoice.getErrors().setTPA_Extension(new TPA_Extension());
                }
                for (int i = 0; i < anyExceptions.length; i++)
                {
                    AnyException e = anyExceptions[i];
                    if (e != null)
                    {
                        Error err = new Error();
                        err.setType(ERROR_DEFAULT_TYPE);
                        ErrorCode code = new ErrorCode();
                        err.setErrorCode(code);
                        code.setContext(e.getContext());
                        code.setMajorCode(e.getMajor());
                        code.setWarningCode(e.getMinor());
                        code.setDescription(e.getMessage());
                        reservationChangeAssessmentSvRSChoice.getErrors().getTPA_Extension().addError(err);
                    }
                }
            }
        }
    }
}

package com.datalex.servants.reservation.changeassessment.bean;

import javax.ejb.EJBObject;

import com.datalex.xsf.messaging.ConvServantDispatcher;
/**
 * The J2EE-Framework required "Remote" interface for the Reservation Change Assessment Service
 * @author $Author$
 */
public interface ReservationChangeAssessmentSv extends EJBObject, ConvServantDispatcher
{
    //Intentionally blank
}

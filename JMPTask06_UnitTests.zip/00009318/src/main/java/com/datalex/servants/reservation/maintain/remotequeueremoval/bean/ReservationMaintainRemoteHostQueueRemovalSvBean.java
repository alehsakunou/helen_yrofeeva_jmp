/**
 * Copyright (C) 2015 Datalex. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Datalex
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * licence agreement you entered into with Datalex.
 *
 */
package com.datalex.servants.reservation.maintain.remotequeueremoval.bean;

import com.datalex.cbp.rqrs.CBPSvRQBase;
import com.datalex.cbp.rqrs.CBPSvRSBase;
import com.datalex.exception.codes.M3_AdaptorConfigMinorCodes;
import com.datalex.exception.codes.M3_AirMinorCodes;
import com.datalex.exception.codes.M3_ContextCodes;
import com.datalex.exception.codes.M3_MajorCodes;
import com.datalex.matrix.servants.TDPBusinessServantBase;
import com.datalex.matrix.servants.ota.air.util.WarningUtil;
import com.datalex.matrix.servants.resolution.adaptor.AdaptorApplication;
import com.datalex.mw.exception.AnyException;
import com.datalex.mw.persistence.DBAccess;
import com.datalex.ota.rqrs.air.Warning;
import com.datalex.ota.rqrs.air.extensions.types.errors.Error;
import com.datalex.ota.rqrs.air.extensions.types.errors.ErrorCode;
import com.datalex.ota.rqrs.air.extensions.types.errors.TPA_Extension;
import com.datalex.rqrs.reservation.notification.Errors;
import com.datalex.rqrs.reservation.notification.ReservationRemoteHostQueueRemovalSvRQ;
import com.datalex.rqrs.reservation.notification.ReservationRemoteHostQueueRemovalSvRS;
import com.datalex.rqrs.reservation.notification.ReservationRemoteHostQueueRemovalSvRSSequence;
import com.datalex.rqrs.reservation.notification.Warnings;
import com.datalex.xsf.messaging.ServiceException;

/**
 * Facade Added for the Notification Scheduler.
 * Reservation maintain remote host queue removal enterprise bean class.
 * @ejb:bean name="ReservationMaintainRemoteHostQueueRemovalSv"
 *           display-name="ReservationMaintainRemoteHostQueueRemovalSv"
 *           generate="true"
 *           type="Stateless"
 *           transaction-type="Container"
 *           view-type="remote"
 * @ejb:home
 *           remote-class=
 *           "com.datalex.servants.reservation.maintain.remotequeueremoval.bean.ReservationMaintainRemoteHostQueueRemovalSvHome"
 * @ejb:interface
 *                remote-class=
 *                "com.datalex.servants.reservation.maintain.remotequeueremoval.bean.ReservationMaintainRemoteHostQueueRemovalSv"
 * @ejb:transaction type="NotSupported"
 * @ejb:env-entry name="policy"
 *                type="java.lang.String"
 *                value="ReservationMaintainRemoteHostQueueRemovalSv"
 * 
 * @weblogic:enable-call-by-reference True
 * @weblogic:pool initial-beans-in-free-pool="0" max-beans-in-free-pool="100"
 * @weblogic:clustering stateless-bean-is-clusterable="True"
 * 
 * @dlex:MatrixBusinessServant type="ReservationMaintainRemoteHostQueueRemoval"
 *                             description="Generates a policy with id=ReservationMaintainRemoteHostQueueRemovalSv"
 *                             extends="TDPBusinessServantBase"
 * 
 * @dlex:bean-property name="ResponseType" value="com.datalex.rqrs.reservation.notification.ReservationRemoteHostQueueRemovalSvRS"
 *                     description="This is the response type for this service"
 * @dlex:bean-property name="ServiceId" value="ReservationMaintainRemoteHostQueueRemovalSv"
 *                     description="This is the TDP service name"
 * 
 * @dlex:ErrorDeclaration ref="com.datalex.exception.codes.M3_ContextCodes.OTA_SERVANT_CONTEXT_CODE"
 * @dlex:ErrorDeclaration ref="com.datalex.exception.codes.M3_MajorCodes.MANAGE_SERVANT_CONTEXT"
 * @dlex:ErrorDeclaration ref="com.datalex.exception.codes.M3_AirMinorCodes.INVALID_RESPONSE_FROM_SERVANT"
 */
public class ReservationMaintainRemoteHostQueueRemovalSvBean extends TDPBusinessServantBase
{
    /** eclipse generated serialVersionUID */
    private static final long serialVersionUID = 7996187353158563338L;
    /** A static int that defines the maximum number of adaptors that should have been resolved **/
    private static final int MAX_RESOLVED_ADAPTORS = 1;

    /**
     * This method initialises any properties for the servant. These will be applied accordingly
     */
    public void init()
    {
        super.init();
        if (isDebugEnabled())
        {
            debug("Initialising the ReservationMaintainRemoteHostQueueRemovalSv service...");
        }
        //m_enablePOSOverride = true;
    }

    /**
     * Get the request class
     * @return the request class type
     */
    protected final Class getRQClass()
    {
        return ReservationRemoteHostQueueRemovalSvRQ.class;
    }

    /**
     * This method should be implemented in all subclass implementations. This method should set the remote system code
     * retrieved from the adaptor configuration in the associated specific XML request.
     *
     * @param request This is the XML request to be updated
     * @param remoteSystemCode The remote system code to be inserted
     */
    @Override
    protected void setRemoteSystemCode(CBPSvRQBase request, String remoteSystemCode)
    {
    }

    /**
     * Servant request contains a list of reservation information to allow PNRs to be removed from the Notification Queue.
     * Sends this request to a configured adaptor and returns response returned by this adaptor.
     * Only one adaptor can be resolved for this service.
     * 
     * @param request Request object in the case the {@link ReservationRemoteHostQueueRemovalSvRQ} reference
     * @param resolvedAdaptors This is the array of {@link AdaptorApplication}s or resolved set of adaptors.
     * @param dbAccess The {@link DBAccess} reference used to access a database - not used for this service.
     * 
     * @return Reservation Remote Host Queue Removal response.
     */
    @Override
    protected CBPSvRSBase processRequest(CBPSvRQBase request, AdaptorApplication[] resolvedAdaptors, DBAccess dbAccess)
    {
        /*
         * We only ever want to go to one system for the Remote Host Queue Removal service - hence the need to ensure
         * that only one adaptor will be called in the event for some reason more than one adaptor configuration
         * is returned after the call to the AdaptorManageSv service
         * 
         * The first adaptor in the list returned is taken as the adaptor to be executed.
         * 
         * Only one adaptor[MAX_RESOLVED_ADAPTORS] can be resolved for this service.
         * If there are more than one, only the first one will be used,
         * and warnings added to the response for the others.
         */
        if (resolvedAdaptors == null)
        {
            throw new AnyException("The array of resolved adaptors is Null",
                    M3_ContextCodes.RESERVATION_CONTEXT_CODE, M3_MajorCodes.MANAGE_SERVANT_CONTEXT,
                    M3_MajorCodes.BASE_SERVANT_ADAPTER_UNHANDLED_EXCEPTION);
        }

        AdaptorApplication[] adaptorApplications = resolvedAdaptors;
        if (resolvedAdaptors.length > MAX_RESOLVED_ADAPTORS)
        {
            adaptorApplications = new AdaptorApplication[MAX_RESOLVED_ADAPTORS];
            for (int i = 0; i < MAX_RESOLVED_ADAPTORS; i++)
            {
                adaptorApplications[i] = resolvedAdaptors[i];
            }
        }
        ReservationRemoteHostQueueRemovalSvRQ queueRemovalSvRQ = (ReservationRemoteHostQueueRemovalSvRQ) request;
        AnyException[] anyExceptions = new ServiceException[adaptorApplications.length];
        ReservationRemoteHostQueueRemovalSvRQ[] adaptorRequests =
                new ReservationRemoteHostQueueRemovalSvRQ[adaptorApplications.length];

        // Send the request to adaptor and receive a response.
        ReservationRemoteHostQueueRemovalSvRS[] responses = (ReservationRemoteHostQueueRemovalSvRS[]) sendReceive(queueRemovalSvRQ,
                adaptorRequests, adaptorApplications, anyExceptions);

        /* Check that the responses have a valid set of values */
        if ((responses == null) || (responses.length <= 0) || (responses[0] == null))
        {
            throw new AnyException("No responses received for the ReservationMaintainRemoteHostQueueRemoval service request",
                    M3_ContextCodes.RESERVATION_CONTEXT_CODE, M3_MajorCodes.MANAGE_SERVANT_CONTEXT,
                    M3_AirMinorCodes.INVALID_RESPONSE_FROM_SERVANT);
        }

        ReservationRemoteHostQueueRemovalSvRS queueRemovalSvRS = processResponse(adaptorRequests, responses, adaptorApplications,
                anyExceptions);

        /*
         * Now deal with the case where more than one adaptor was returned -- should never happen
         * in reality - however the user may configure the system incorrectly
         * If this is the case just add a warning for each of the other adaptors that were configured
         */
        if (resolvedAdaptors.length > MAX_RESOLVED_ADAPTORS)
        {
            addAdapterCountWarnings(queueRemovalSvRS, resolvedAdaptors, adaptorApplications);
        }

        return queueRemovalSvRS;
    }

    /**
     * This method deals with the case where more than one adaptor was returned -- should never happen
     * in reality - however the user may configure the system incorrectly.
     * If this is the case just add a warning for each of the other adaptors that were configured.
     * 
     * @param queueRemovalSvRS This is the {@link ReservationRemoteHostQueueRemovalSvRS} to be updated
     * @param resolvedAdaptors This is the array of {@link AdaptorApplication} resolved adaptors
     * @param adaptorApplications This is the set of adaptor configurations used when calling the host systems
     *            (this is a subset of the resolvedAdaptors - usually the first one)
     */
    private void addAdapterCountWarnings(ReservationRemoteHostQueueRemovalSvRS queueRemovalSvRS,
            AdaptorApplication[] resolvedAdaptors, AdaptorApplication[] adaptorApplications)
    {
        if (isDebugEnabled())
        {
            debug("Entered addAdapterCountWarnings for the ReservationRemoteHostQueueRemoval Service...");
        }

        ReservationRemoteHostQueueRemovalSvRSSequence seq = queueRemovalSvRS.getReservationRemoteHostQueueRemovalSvRSSequence();
        if (seq == null)
        {
            seq = new ReservationRemoteHostQueueRemovalSvRSSequence();
            queueRemovalSvRS.setReservationRemoteHostQueueRemovalSvRSSequence(seq);
        }
        if (seq.getWarnings() == null)
        {
            seq.setWarnings(new Warnings());
        }
        Warnings warnings = seq.getWarnings();
        for (int i = adaptorApplications.length; i < resolvedAdaptors.length; i++)
        {
            String description = "Adaptor: " + resolvedAdaptors[i].getName() + " has not been processed as only "
                    + MAX_RESOLVED_ADAPTORS + " adaptor(s) may be used for this service";
            
            Warning warning = WarningUtil.createWarning(M3_ContextCodes.SERVICEBASE_CONTEXT_CODE,
                    M3_MajorCodes.M3_BASECLASSES_MAJOR_CODE, M3_AdaptorConfigMinorCodes.TOO_MANY_RESOLVED_ADAPTORS, description);

            warnings.addWarning(warning);
        }

    }

    /**
     * This method add warnings in the
     * response when an exception occurs (e.g. no adaptors found, etc.)
     *
     * @param request - The request
     * @param appException - The Exception to be processed
     * @return CBPSvRSBase
     */
    @Override
    protected CBPSvRSBase addWarning(CBPSvRQBase request, AnyException appException)
    {
        ReservationRemoteHostQueueRemovalSvRS response = new ReservationRemoteHostQueueRemovalSvRS();
        response.setMajorVersion(request.getMajorVersion());
        response.setMinorVersion(request.getMinorVersion());
        response.setClientId(request.getClientId());
        if (request.getUniqueId() != null)
        {
            response.setUniqueId(request.getUniqueId());
        }

        response.setReservationRemoteHostQueueRemovalSvRSSequence(new ReservationRemoteHostQueueRemovalSvRSSequence());
        response.getReservationRemoteHostQueueRemovalSvRSSequence().setWarnings(new Warnings());
        Warnings warnings = response.getReservationRemoteHostQueueRemovalSvRSSequence().getWarnings();
        Warning warning = WarningUtil.createWarning(M3_ContextCodes.SERVICEBASE_CONTEXT_CODE, appException.getMajor(),
                appException.getMinor(), appException.getMessage());
        warnings.addWarning(warning);

        return response;
    }

    /**
     * Process method that needs to be implemented by the individual servant classes.
     * This method receives the original XML request reference and also a list of responses
     * that have already been received by the adaptors that have been called.
     * This method can be used to execute further specific processing (for example combining all
     * responses into one and potentially removing any duplicate entries).
     *
     * @param adaptorRequests This is the array of {@link ReservationRemoteHostQueueRemovalSvRQ} adaptor requests
     * @param responses This is the array of {@link ReservationRemoteHostQueueRemovalSvRS} responses that have been received
     * @param adaptorApplications This is the array of {@link AdaptorApplication} references
     * @param anyExceptions This is an array of {@link AnyException}s used for populating the responses
     *
     * @return Returns a newly populated {@link DLX_AirBookSvRS} response reference
     * 
     * @see com.datalex.mw.persistence.DBAccess
     */
    private ReservationRemoteHostQueueRemovalSvRS processResponse(ReservationRemoteHostQueueRemovalSvRQ[] adaptorRequests,
            ReservationRemoteHostQueueRemovalSvRS[] responses, AdaptorApplication[] adaptorApplications,
            AnyException[] anyExceptions)
    {
        if (isDebugEnabled())
        {
            debug("Entered processResponse for the ReservationRemoteHostQueueRemoval Service...");
        }
        /*
         * It is only possible at the moment to send one queue removal request and to receive one queue removal response.
         * This is the XSD definition and it makes sense. Hence there is no need merge responses as there will only
         * ever be one response
         */
        /* Get the response from adaptor. Just take the first request as this is all that is required for the moment */
        ReservationRemoteHostQueueRemovalSvRS queueRemovalResponse = responses[0];

        // handle anyExceptions
        if (anyExceptions != null && anyExceptions.length > 0)
        {
            int count = 0;
            for (int i = 0; i < anyExceptions.length; i++)
            {
                if (anyExceptions[i] != null)
                {
                    count++;
                }
            }
            if (count > 0)
            {
                if (queueRemovalResponse.getErrors() == null)
                {
                    queueRemovalResponse.setErrors(new Errors());
                }
                if (queueRemovalResponse.getErrors().getTPA_Extension() == null)
                {
                    queueRemovalResponse.getErrors().setTPA_Extension(new TPA_Extension());
                }
                for (int i = 0; i < anyExceptions.length; i++)
                {
                    AnyException e = anyExceptions[i];
                    if (e != null)
                    {
                        Error err = new Error();
                        err.setType("1.ERR");
                        ErrorCode code = new ErrorCode();
                        err.setErrorCode(code);
                        code.setContext(e.getContext());
                        code.setMajorCode(e.getMajor());
                        code.setWarningCode(e.getMinor());
                        code.setDescription(e.getMessage());
                        queueRemovalResponse.getErrors().getTPA_Extension().addError(err);
                    }
                }
            }
        }

        if (isDebugEnabled())
        {
            debug("Exiting processResponse for the ReservationRemoteHostQueueRemoval Service...");
        }
        return queueRemovalResponse;
    }

}

package com.datalex.servants.reservation.changeassessment.bean;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.EJBHome;

/**
 * The J2EE-framework required "Home" interface for the Reservation Change Assessment Service
 * @author $Author$
 */
public interface ReservationChangeAssessmentSvHome extends EJBHome
{
    /**
     * Create a new instance of the remote host queue removal bean
     * @return the remote host queue removal bean
     * @throws RemoteException if an error occurs during create
     * @throws CreateException if an error occurs during create
     */
    ReservationChangeAssessmentSv create() throws RemoteException, CreateException;
}

package com.epam.helenyrofeeva.bottleneck;

public class RunnerBottleneck {

	public static void main(String[] args) {
		SomeLogic s1 = new SomeLogic();

		new Thread(new ThreadBottleneck(s1," threadX " + 0, 10)).start();
		new Thread(new ThreadBottleneck(s1," threadX " + 1, 50000)).start();
		for (int i = 2; i < 10; i++) {
			new Thread(new ThreadBottleneck(s1," threadX " + i, 10)).start();
		}
	}

}

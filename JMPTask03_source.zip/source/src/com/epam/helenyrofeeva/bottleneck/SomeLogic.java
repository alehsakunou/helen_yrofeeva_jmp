package com.epam.helenyrofeeva.bottleneck;

public class SomeLogic {

	protected synchronized void oneStep(int gap){
		try {
			Thread.sleep(gap);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}		
	}
	
	public void doSomething(int gap){
		oneStep(gap);
	}

}

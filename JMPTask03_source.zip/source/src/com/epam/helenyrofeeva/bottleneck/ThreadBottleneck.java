package com.epam.helenyrofeeva.bottleneck;

public class ThreadBottleneck implements Runnable{
	private SomeLogic obj;
	private String name;
	private int gap;
	
	public ThreadBottleneck(SomeLogic obj, String name, int gap) {
		this.obj = obj;
		this.name = name;
		this.gap = gap;
	}
	
	@Override
	public void run() {
		System.out.println(name + " started ");
		obj.doSomething(gap);
		System.out.println(name + " finished " + gap);
	}

}

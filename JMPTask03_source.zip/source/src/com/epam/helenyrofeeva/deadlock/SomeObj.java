package com.epam.helenyrofeeva.deadlock;

public class SomeObj {
	private int data;

	public int getData() {
		return data;
	}

	public synchronized void setData(int data) {
		this.data = data;
	}

}

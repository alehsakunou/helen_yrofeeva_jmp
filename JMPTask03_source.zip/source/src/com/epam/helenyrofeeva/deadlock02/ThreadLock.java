package com.epam.helenyrofeeva.deadlock02;

import java.util.Random;

import com.epam.helenyrofeeva.deadlock.SomeObj;

public class ThreadLock implements Runnable{
	private SomeObj obj1;
	private SomeObj obj2;
	private String name;
	private Random rnd = new Random();

	public ThreadLock(SomeObj obj1, SomeObj obj2, String name) {
		this.obj1 = obj1;
		this.obj2 = obj2;
		this.name = name;
	}

	private void doSomething() {
		synchronized (obj1) {
			try {
				Thread.sleep(rnd.nextInt(2));
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

			obj2.setData(obj1.getData() + 1);
		}
	}

	@Override
	public void run() {
		System.out.println(name + " started ");
		doSomething();
		System.out.println(name + " finished 1=" + obj1.getData() + " 2=" + obj2.getData());
	}
}

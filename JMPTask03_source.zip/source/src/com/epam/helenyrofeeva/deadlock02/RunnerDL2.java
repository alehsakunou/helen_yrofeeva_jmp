package com.epam.helenyrofeeva.deadlock02;

import com.epam.helenyrofeeva.deadlock.SomeObj;

public class RunnerDL2 {

	public static void main(String[] args) {
		SomeObj s1 = new SomeObj();
		SomeObj s2 = new SomeObj();
		SomeObj s3 = new SomeObj();
		SomeObj s4 = new SomeObj();

		for (int i = 0; i < 4; i++) {
			new Thread(new ThreadLock(s1, s2, " threadX " + i)).start();
			new Thread(new ThreadLock(s2, s3, " threadY " + i)).start();
			new Thread(new ThreadLock(s3, s4, " threadZ " + i)).start();
			new Thread(new ThreadLock(s4, s1, " threadU " + i)).start();
		}

	}

}

package com.epam.helenyrofeeva.deadlock01;

import com.epam.helenyrofeeva.deadlock.SomeObj;

public class RunnerDL0 {
	public static void main(String[] args) {
		SomeObj s1 = new SomeObj();
		SomeObj s2 = new SomeObj();

		for (int i = 0; i < 10; i++) {
			new Thread(new ThreadLock0(s1, s2, " threadX " + i)).start();
			new Thread(new ThreadLock0(s2, s1, " threadY " + i)).start();
		}
	}
}

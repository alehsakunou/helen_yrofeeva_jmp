package com.epam.helenyrofeeva.deadlock01;

import java.util.Random;

import com.epam.helenyrofeeva.deadlock.SomeObj;

public class ThreadLock0 implements Runnable {
	private SomeObj obj1;
	private SomeObj obj2;
	private String name;
	private Random rnd = new Random();

	public ThreadLock0(SomeObj obj1, SomeObj obj2, String name) {
		this.obj1 = obj1;
		this.obj2 = obj2;
		this.name = name;
	}

	@Override
	public void run() {
		System.out.println(name + " started ");
		synchronized (obj1) {
			System.out.println(name + " in block1");
			try {
				Thread.sleep(rnd.nextInt(2));
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			synchronized (obj2) {
				System.out.println(name + " in block2");
			}
			
		}
		System.out.println(name + " finished ");
	}
}

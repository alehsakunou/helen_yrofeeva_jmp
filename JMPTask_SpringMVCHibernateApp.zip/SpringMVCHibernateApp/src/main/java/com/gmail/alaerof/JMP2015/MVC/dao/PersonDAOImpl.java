package com.gmail.alaerof.JMP2015.MVC.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.gmail.alaerof.JMP2015.MVC.model.Person;

public class PersonDAOImpl implements PersonDAO {
    protected static final Logger logger = LoggerFactory.getLogger(PersonDAOImpl.class);
    private SessionFactory sessionFactory;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public void updatePerson(Person p) {
        Session session = this.sessionFactory.openSession();
        Transaction trans = session.beginTransaction();
        session.save(p);
        trans.commit();
        logger.info("Person updated successfully, person details = " + p);
    }

    @SuppressWarnings("unchecked")
    public List<Person> listPersons() {
        Session session = this.sessionFactory.openSession();
        List<Person> personList = session.createQuery("from Person").list();
        logger.info("Person count = " + personList.size());
        return personList;
    }

    public void dropAll() {
        Session session = this.sessionFactory.openSession();
        Query q = session.createQuery("delete Person where id > 0");
        q.executeUpdate();
        logger.info("All person deleted successfully");
    }

    public Person getPersonById(int id) {
        Session session = this.sessionFactory.openSession();
        Person p = (Person) session.get(Person.class, new Integer(id));
        logger.info("Person loaded successfully, Person details = " + p);
        return p;
    }

    public void addPerson(Person p) {
        Session session = this.sessionFactory.getCurrentSession();
        Transaction trans = session.beginTransaction();
        session.save(p);
        trans.commit();
        logger.info("Person saved successfully, Person Details = " + p);
    }

    public void removePerson(int id) {
        Session session = this.sessionFactory.openSession();
        Person p = (Person) session.get(Person.class, new Integer(id));
        if (null != p) {
            session.delete(p);
        }
        logger.info("Person deleted successfully, person details = " + p);
    }
}

package com.gmail.alaerof.JMP2015.MVC.service;

import java.util.List;

import com.gmail.alaerof.JMP2015.MVC.model.Person;

public interface PersonService {
    public void addPerson(Person p);
    public void updatePerson(Person p);
    public List<Person> listPersons();
    public Person getPersonById(int id);
    public void removePerson(int id);
}

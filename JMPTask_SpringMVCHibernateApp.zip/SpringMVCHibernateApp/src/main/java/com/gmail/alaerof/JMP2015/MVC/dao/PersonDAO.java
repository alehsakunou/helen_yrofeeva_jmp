package com.gmail.alaerof.JMP2015.MVC.dao;

import java.util.List;

import com.gmail.alaerof.JMP2015.MVC.model.Person;

public interface PersonDAO {
    public List<Person> listPersons();
    public Person getPersonById(int id);
    public void updatePerson(Person p);
    public void addPerson(Person p);
    public void removePerson(int id);   
    public void dropAll();
}
